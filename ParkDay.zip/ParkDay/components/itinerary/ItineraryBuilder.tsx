'use client';

import { FormEvent, useMemo, useState } from 'react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { EmptyState, InlineNotice } from '@/components/ui/EmptyState';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import type { ItineraryItem } from '@/lib/types';
import { downloadTextFile } from '@/lib/utils';

const types: ItineraryItem['type'][] = ['attraction', 'dining', 'show', 'break', 'transportation', 'note'];

export function ItineraryBuilder() {
  const itinerary = useParkDayStore((state) => state.itinerary);
  const addItineraryItem = useParkDayStore((state) => state.addItineraryItem);
  const removeItineraryItem = useParkDayStore((state) => state.removeItineraryItem);
  const reorderItinerary = useParkDayStore((state) => state.reorderItinerary);
  const updateItineraryItem = useParkDayStore((state) => state.updateItineraryItem);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [title, setTitle] = useState('Midday break');
  const [type, setType] = useState<ItineraryItem['type']>('break');
  const [startTime, setStartTime] = useState('13:00');
  const [endTime, setEndTime] = useState('14:00');
  const [notes, setNotes] = useState('Hydrate, charge phones, sit indoors.');
  const sorted = [...itinerary].sort((a, b) => a.startTime.localeCompare(b.startTime));
  const warnings = useMemo(() => findConflicts(sorted), [sorted]);

  function submit(event: FormEvent) {
    event.preventDefault();
    addItineraryItem({ title, type, startTime, endTime, notes });
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Itinerary" title="A timeline you can rearrange with thumbs or a mouse.">
        Add attractions, dining, shows, breaks, transport, and notes. Plans persist locally and export cleanly.
      </SectionTitle>
      <div className="grid gap-6 lg:grid-cols-[22rem_1fr]">
        <Card className="no-print lg:sticky lg:top-28 lg:self-start">
          <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Add to plan</h2>
          <form onSubmit={submit} className="grid gap-4">
            <label className="grid gap-2 text-sm font-bold text-cream/70">Title<input className="input" value={title} onChange={(event) => setTitle(event.target.value)} required /></label>
            <label className="grid gap-2 text-sm font-bold text-cream/70">Type<select className="input" value={type} onChange={(event) => setType(event.target.value as ItineraryItem['type'])}>{types.map((item) => <option key={item}>{item}</option>)}</select></label>
            <div className="grid grid-cols-2 gap-3"><label className="grid gap-2 text-sm font-bold text-cream/70">Start<input type="time" className="input" value={startTime} onChange={(event) => setStartTime(event.target.value)} /></label><label className="grid gap-2 text-sm font-bold text-cream/70">End<input type="time" className="input" value={endTime} onChange={(event) => setEndTime(event.target.value)} /></label></div>
            <label className="grid gap-2 text-sm font-bold text-cream/70">Notes<textarea className="input min-h-24" value={notes} onChange={(event) => setNotes(event.target.value)} /></label>
            <Button type="submit" variant="gold">Add item</Button>
          </form>
          <div className="mt-4 grid gap-2"><Button onClick={() => downloadTextFile('parkday-itinerary.json', JSON.stringify(itinerary, null, 2))}>Export JSON</Button><Button onClick={() => window.print()}>Print view</Button><Button>Calendar file placeholder</Button></div>
        </Card>
        <div className="space-y-5">
          {warnings.length ? <InlineNotice>{warnings.join(' ')}</InlineNotice> : null}
          {sorted.length ? sorted.map((item, index) => (
            <Card key={item.id} className="print-card" draggable onDragStart={() => setDragIndex(index)} onDragOver={(event) => event.preventDefault()} onDrop={() => { if (dragIndex !== null) reorderItinerary(dragIndex, index); setDragIndex(null); }}>
              <div className="grid gap-4 md:grid-cols-[6rem_1fr_auto]">
                <div><Badge>{item.startTime}</Badge><p className="mt-2 text-sm font-bold text-cream/45">to {item.endTime}</p></div>
                <div><Badge>{item.type}</Badge><h3 className="mt-3 text-2xl font-black text-cream light:text-slate-950">{item.title}</h3><p className="mt-2 text-sm leading-6 text-cream/62 light:text-slate-600">{item.notes || 'No notes yet.'}</p></div>
                <div className="no-print flex flex-wrap gap-2 md:flex-col"><Button disabled={index === 0} onClick={() => reorderItinerary(index, index - 1)}>↑</Button><Button disabled={index === sorted.length - 1} onClick={() => reorderItinerary(index, index + 1)}>↓</Button><Button onClick={() => updateItineraryItem(item.id, { completed: !item.completed })}>{item.completed ? 'Done' : 'Mark done'}</Button><Button variant="danger" onClick={() => removeItineraryItem(item.id)}>Remove</Button></div>
              </div>
            </Card>
          )) : <EmptyState title="Your timeline is empty" body="Add a break, attraction, meal, show, or transportation item. Live waits and dining cards can also send items here." />}
        </div>
      </div>
    </div>
  );
}

function findConflicts(items: ItineraryItem[]) {
  const warnings: string[] = [];
  for (let index = 0; index < items.length - 1; index += 1) {
    const current = items[index];
    const next = items[index + 1];
    if (current.endTime > next.startTime) warnings.push(`Looks like ${current.title} overlaps ${next.title}.`);
    if (current.type !== 'transportation' && next.type !== 'transportation' && timeGapMinutes(current.endTime, next.startTime) < 15) warnings.push(`Add a little buffer between ${current.title} and ${next.title}.`);
  }
  if (items.filter((item) => item.type === 'transportation').length === 0 && items.length > 2) warnings.push('Route time is not included yet. Add transportation before park hops or hotel returns.');
  return [...new Set(warnings)].slice(0, 3);
}

function timeGapMinutes(a: string, b: string) {
  const [ah, am] = a.split(':').map(Number);
  const [bh, bm] = b.split(':').map(Number);
  return (bh * 60 + bm) - (ah * 60 + am);
}
