'use client';

import { useMemo, useState } from 'react';
import { Badge } from '@/components/ui/Badge';
import { BottomSheet } from '@/components/ui/BottomSheet';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { InlineNotice } from '@/components/ui/EmptyState';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import type { MapPin } from '@/lib/types';
import pinsSeed from '@/data/seed/mapPins.json';
import parksSeed from '@/data/seed/parks.json';

const pins = pinsSeed as MapPin[];
const parks = parksSeed as Array<{ id: string; name: string }>;
const pinIcons: Record<MapPin['type'], string> = { attraction: '⌁', dining: '◡', restroom: 'WC', transportation: '↬', 'guest-services': '?', 'first-aid': '+', water: '≈' };

export function InteractiveMap() {
  const [park, setPark] = useState('Magic Kingdom');
  const [mode, setMode] = useState<'map' | 'list'>('map');
  const [selected, setSelected] = useState<MapPin | null>(null);
  const [locationState, setLocationState] = useState<'idle' | 'asking' | 'denied' | 'ready'>('idle');
  const favorites = useParkDayStore((state) => state.favorites);
  const toggleFavorite = useParkDayStore((state) => state.toggleFavorite);
  const visiblePins = useMemo(() => pins.filter((pin) => pin.park === park), [park]);

  function nearMe() {
    if (!navigator.geolocation) {
      setLocationState('denied');
      return;
    }
    setLocationState('asking');
    navigator.geolocation.getCurrentPosition(
      () => setLocationState('ready'),
      () => setLocationState('denied'),
      { enableHighAccuracy: false, timeout: 6000 }
    );
  }

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Interactive map" title="Map when you need it, list when you are walking.">
        Coordinates are clean seed abstractions. Replace them with verified coordinates or a Mapbox/MapLibre/Leaflet layer later.
      </SectionTitle>
      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {parks.map((item) => <button key={item.name} onClick={() => setPark(item.name)} className={`rounded-full border px-4 py-2 text-sm font-bold ${park === item.name ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/70 hover:bg-white/10'}`}>{item.name}</button>)}
          </div>
          <div className="flex gap-2"><Button onClick={() => setMode(mode === 'map' ? 'list' : 'map')}>{mode === 'map' ? 'List view' : 'Map view'}</Button><Button variant="gold" onClick={nearMe}>Near me</Button></div>
        </div>
        <p className="mt-4 text-sm leading-6 text-cream/58 light:text-slate-600">Location is used only for an in-session nearby placeholder. ParkDay explains permission before requesting and keeps saved plans offline-friendly.</p>
      </Card>
      {locationState === 'asking' ? <InlineNotice>Requesting location permission…</InlineNotice> : null}
      {locationState === 'denied' ? <InlineNotice>Location was not available. You can still use map pins, route shortcuts, and saved plans manually.</InlineNotice> : null}
      {locationState === 'ready' ? <InlineNotice>Location permission granted. Add verified coordinates to power true “near me” sorting.</InlineNotice> : null}

      {mode === 'map' ? (
        <Card className="overflow-hidden p-0">
          <div className="relative h-[70vh] min-h-[34rem] overflow-hidden bg-[radial-gradient(circle_at_35%_30%,rgba(112,200,255,0.22),transparent_20rem),radial-gradient(circle_at_70%_65%,rgba(246,217,138,0.18),transparent_18rem),rgba(255,255,255,0.05)]">
            <div className="absolute inset-8 rounded-[3rem] border border-white/10 bg-white/[0.04]" />
            <div className="absolute left-[12%] top-[12%] rounded-full border border-white/10 bg-white/[0.05] px-4 py-2 text-sm font-black text-cream/45">{park} seed map</div>
            {visiblePins.map((pin) => <button key={pin.id} onClick={() => setSelected(pin)} className={`absolute grid min-h-12 min-w-12 place-items-center rounded-2xl border text-sm font-black shadow-card transition hover:scale-110 ${favorites.includes(pin.id) ? 'border-gold bg-gold text-midnight' : 'border-white/15 bg-midnight/80 text-cream'}`} style={{ left: `${pin.x}%`, top: `${pin.y}%` }} aria-label={`Open ${pin.name}`}>{pinIcons[pin.type]}</button>)}
          </div>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visiblePins.map((pin) => <Card key={pin.id}><Badge>{pin.type}</Badge><h3 className="mt-3 text-xl font-black text-cream light:text-slate-950">{pin.name}</h3><p className="mt-2 text-sm leading-6 text-cream/58 light:text-slate-600">{pin.notes}</p><div className="mt-4 flex gap-2"><Button onClick={() => setSelected(pin)}>Details</Button><Button variant="gold" onClick={() => toggleFavorite(pin.id, pin.name)}>{favorites.includes(pin.id) ? 'Saved' : 'Save'}</Button></div></Card>)}
        </div>
      )}
      <BottomSheet open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.name ?? 'Map detail'} footer={selected ? <div className="grid grid-cols-2 gap-3"><Button variant="gold" onClick={() => toggleFavorite(selected.id, selected.name)}>{favorites.includes(selected.id) ? 'Saved' : 'Save'}</Button><Button>Get route</Button></div> : null}>
        {selected ? <div className="space-y-4"><Badge>{selected.park}</Badge><p className="text-sm leading-6 text-cream/70 light:text-slate-700">{selected.notes ?? 'Add details in the seed file.'}</p><InlineNotice>Live wait badges appear when an attraction pin can be matched to ThemeParks.wiki live data. Current seed pins intentionally avoid pretending exact coordinates are verified.</InlineNotice></div> : null}
      </BottomSheet>
    </div>
  );
}
