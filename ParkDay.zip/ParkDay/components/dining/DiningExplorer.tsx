'use client';

import { useMemo, useState } from 'react';
import { Badge } from '@/components/ui/Badge';
import { BottomSheet } from '@/components/ui/BottomSheet';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { EmptyState, InlineNotice } from '@/components/ui/EmptyState';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import type { DiningLocation } from '@/lib/types';
import diningSeed from '@/data/seed/dining.json';

const dining = diningSeed as DiningLocation[];
const filterGroups = {
  location: ['Magic Kingdom', 'EPCOT', 'Hollywood Studios', 'Animal Kingdom', 'Disney Springs'],
  type: ['Quick service', 'Table service', 'Character dining', 'Lounge', 'Snack'],
  dietary: ['Vegetarian', 'Vegan', 'Gluten-friendly', 'Allergy-friendly placeholder'],
  tags: ['Mobile order placeholder', 'Reservations recommended', 'Indoor', 'Outdoor seating']
};

export function DiningExplorer() {
  const [query, setQuery] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [selected, setSelected] = useState<DiningLocation | null>(null);
  const toggleFavorite = useParkDayStore((state) => state.toggleFavorite);
  const favorites = useParkDayStore((state) => state.favorites);
  const addItineraryItem = useParkDayStore((state) => state.addItineraryItem);
  const filtered = useMemo(() => dining.filter((item) => {
    const text = `${item.name} ${item.location} ${item.parkOrResort} ${item.type} ${item.cuisine.join(' ')} ${item.tags.join(' ')} ${item.dietaryTags.join(' ')}`.toLowerCase();
    if (!text.includes(query.toLowerCase())) return false;
    return selectedFilters.every((filter) => text.includes(filter.toLowerCase()));
  }), [query, selectedFilters]);

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Dining" title="Find a meal that fits the day, not just the map.">
        Dining seed data is manually maintained. Reservation and mobile-order availability are placeholders unless you connect a legal, verified source.
      </SectionTitle>
      <InlineNotice>ParkDay does not scrape Disney dining pages. Add official links or third-party APIs only when you have permission and a stable data source.</InlineNotice>
      <Card>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto]">
          <label className="grid gap-2 text-sm font-bold text-cream/70" htmlFor="dining-search">Search restaurants<input id="dining-search" className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try lounge, vegan, EPCOT, indoor…" /></label>
          <label className="grid gap-2 text-sm font-bold text-cream/70">Price level<select className="input" onChange={(event) => event.target.value && setSelectedFilters((current) => current.includes(event.target.value) ? current : [...current, event.target.value])}><option value="">Any price</option><option>$</option><option>$$</option><option>$$$</option><option>$$$$</option></select></label>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {Object.entries(filterGroups).map(([label, values]) => <div key={label}><p className="mb-2 text-xs font-extrabold uppercase tracking-[0.18em] text-cream/44">{label}</p><div className="flex flex-wrap gap-2">{values.map((filter) => { const active = selectedFilters.includes(filter); return <button key={filter} onClick={() => setSelectedFilters((current) => active ? current.filter((item) => item !== filter) : [...current, filter])} className={`rounded-full border px-3 py-1.5 text-xs font-bold ${active ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/65 hover:bg-white/10'}`}>{filter}</button>; })}</div></div>)}
        </div>
      </Card>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((restaurant) => <DiningCard key={restaurant.id} restaurant={restaurant} favorite={favorites.includes(restaurant.id)} onSelect={() => setSelected(restaurant)} onFavorite={() => toggleFavorite(restaurant.id, restaurant.name)} onAdd={() => addItineraryItem({ type: 'dining', title: restaurant.name, park: restaurant.parkOrResort, startTime: restaurant.suggestedTimes[0] ?? '12:00', endTime: restaurant.suggestedTimes[1] ?? '13:00', notes: `${restaurant.type}. ${restaurant.overview}`, sourceId: restaurant.id })} />)}
      </div>
      {!filtered.length ? <EmptyState title="No dining matches" body="Clear a few filters or search by park, cuisine, or dietary tag." /> : null}
      <BottomSheet open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.name ?? 'Dining details'} footer={selected ? <div className="grid grid-cols-2 gap-3"><Button variant="gold" onClick={() => { addItineraryItem({ type: 'dining', title: selected.name, park: selected.parkOrResort, startTime: selected.suggestedTimes[0] ?? '12:00', endTime: selected.suggestedTimes[1] ?? '13:00', notes: selected.overview, sourceId: selected.id }); setSelected(null); }}>Add meal</Button><Button onClick={() => toggleFavorite(selected.id, selected.name)}>Save</Button></div> : null}>
        {selected ? <DiningDetails restaurant={selected} /> : null}
      </BottomSheet>
    </div>
  );
}

function DiningCard({ restaurant, favorite, onSelect, onFavorite, onAdd }: { restaurant: DiningLocation; favorite: boolean; onSelect: () => void; onFavorite: () => void; onAdd: () => void }) {
  return (
    <Card>
      <div className="flex items-start justify-between gap-3"><div><Badge>{restaurant.parkOrResort}</Badge><h3 className="mt-3 text-xl font-black text-cream light:text-slate-950">{restaurant.name}</h3><p className="mt-1 text-sm text-cream/55 light:text-slate-600">{restaurant.location} · {restaurant.type} · {restaurant.priceLevel}</p></div><button onClick={onFavorite} aria-label={favorite ? 'Remove saved restaurant' : 'Save restaurant'} className="grid size-11 place-items-center rounded-2xl border border-white/10 bg-white/10 text-xl">{favorite ? '♥' : '♡'}</button></div>
      <p className="mt-4 text-sm leading-6 text-cream/62 light:text-slate-600">{restaurant.overview}</p>
      <div className="mt-4 flex flex-wrap gap-2">{[...restaurant.cuisine, ...restaurant.dietaryTags].slice(0, 4).map((tag) => <Badge key={tag}>{tag}</Badge>)}</div>
      <div className="mt-5 grid grid-cols-2 gap-2"><Button onClick={onSelect}>Details</Button><Button onClick={onAdd} variant="gold">Add meal</Button></div>
    </Card>
  );
}

function DiningDetails({ restaurant }: { restaurant: DiningLocation }) {
  return (
    <div className="space-y-4">
      <p className="text-sm leading-6 text-cream/70 light:text-slate-700">{restaurant.overview}</p>
      <div className="grid grid-cols-2 gap-3"><Info label="Best for" value={restaurant.bestFor.join(', ')} /><Info label="Suggested time" value={restaurant.suggestedTimes.join(' or ')} /><Info label="Reservation" value={restaurant.reservationRecommended ? 'Recommended' : 'Usually optional'} /><Info label="Mobile order" value={restaurant.mobileOrder ? 'Placeholder ready' : 'Not listed'} /></div>
      <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4"><p className="font-black text-cream light:text-slate-950">Nearby attractions</p><p className="mt-2 text-sm text-cream/62 light:text-slate-600">{restaurant.nearbyAttractions.join(', ') || 'Add nearby attractions later.'}</p></div>
      <div className="grid gap-3 md:grid-cols-2"><Button>Menu link placeholder</Button><Button>Reservation link placeholder</Button></div>
      <textarea className="input min-h-28" placeholder="User notes: allergy reminders, best table, mobile order timing…" />
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) { return <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4"><p className="text-xs font-bold uppercase tracking-[0.18em] text-cream/44">{label}</p><p className="mt-2 text-sm font-bold leading-6 text-cream/74 light:text-slate-700">{value}</p></div>; }
