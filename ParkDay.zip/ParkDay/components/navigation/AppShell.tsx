'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { useNow } from '@/hooks/useNow';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import { cn } from '@/lib/utils';

const desktopNav = [
  { href: '/', label: 'Home' },
  { href: '/plan', label: 'Plan Trip' },
  { href: '/live', label: 'Live Parks' },
  { href: '/routes', label: 'Routes' },
  { href: '/dining', label: 'Dining' },
  { href: '/itinerary', label: 'Itinerary' },
  { href: '/saved', label: 'Saved' }
];

const mobileTabs = [
  { href: '/', label: 'Today', icon: '☀︎' },
  { href: '/live', label: 'Waits', icon: '⌁' },
  { href: '/map', label: 'Map', icon: '◇' },
  { href: '/routes', label: 'Routes', icon: '↬' },
  { href: '/dining', label: 'Dining', icon: '◡' },
  { href: '/plan', label: 'Plan', icon: '+' }
];

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen">
      <DesktopNav />
      <MobileStatusBar />
      <CommandPaletteButton />
      {children}
      <MobileTabBar />
    </div>
  );
}

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-3" aria-label="ParkDay home">
      <span className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-sky via-royal to-gold text-lg font-black text-midnight shadow-glow">P</span>
      <span>
        <span className="block text-base font-black leading-none tracking-tight text-cream light:text-slate-950">ParkDay</span>
        <span className="text-[0.65rem] font-bold uppercase tracking-[0.18em] text-cream/45 light:text-slate-500">Unofficial WDW companion</span>
      </span>
    </Link>
  );
}

function DesktopNav() {
  const pathname = usePathname();
  const favorites = useParkDayStore((state) => state.favorites.length);
  const trip = useParkDayStore((state) => state.tripPlan);
  const theme = useParkDayStore((state) => state.preferences.theme);
  const setPreference = useParkDayStore((state) => state.setPreference);
  const [paletteOpen, setPaletteOpen] = useState(false);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-40 hidden border-b border-white/10 bg-midnight/55 backdrop-blur-2xl md:block">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-8">
        <Brand />
        <nav className="flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.06] p-1" aria-label="Primary navigation">
          {desktopNav.map((item) => {
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href} className={cn('relative rounded-full px-3.5 py-2 text-sm font-bold text-cream/68 transition hover:text-cream', active && 'text-midnight')}>
                {active ? <motion.span layoutId="desktop-nav-pill" className="absolute inset-0 rounded-full bg-cream shadow-sm" transition={{ type: 'spring', stiffness: 360, damping: 32 }} /> : null}
                <span className="relative z-10">{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => setPaletteOpen(true)} aria-label="Open search command palette">⌘K</Button>
          <Link href="/saved" className="rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm font-bold text-cream/78">♡ {favorites}</Link>
          <Badge>{trip ? 'Plan saved' : 'No trip yet'}</Badge>
          <Button variant="secondary" aria-label="Toggle theme" onClick={() => setPreference('theme', theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☾' : '☀'}</Button>
        </div>
      </div>
      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} />
    </header>
  );
}

function MobileStatusBar() {
  const now = useNow(15_000);
  const park = useParkDayStore((state) => state.preferences.selectedParkName ?? 'Choose park');
  const date = useParkDayStore((state) => state.preferences.selectedDate ?? 'Today');
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-white/10 bg-midnight/78 px-4 py-3 backdrop-blur-2xl md:hidden">
      <div className="flex items-center justify-between gap-3">
        <Brand />
        <div className="text-right text-xs font-bold text-cream/62">
          <p>{now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</p>
          <p>Weather soon</p>
        </div>
      </div>
      <div className="mt-3 flex items-center gap-2 overflow-x-auto pb-1">
        <Badge>{park}</Badge>
        <Badge>{date}</Badge>
        <Badge>Saved offline</Badge>
      </div>
    </header>
  );
}

function MobileTabBar() {
  const pathname = usePathname();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-midnight/78 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2 backdrop-blur-2xl md:hidden" aria-label="Mobile navigation">
      <div className="grid grid-cols-6 gap-1">
        {mobileTabs.map((tab) => {
          const active = pathname === tab.href;
          return (
            <Link key={tab.href} href={tab.href} className={cn('relative flex min-h-14 flex-col items-center justify-center gap-1 rounded-2xl text-xs font-extrabold text-cream/55 transition active:scale-95', active && 'text-midnight')}>
              {active ? <motion.span layoutId="mobile-tab" className="absolute inset-0 rounded-2xl bg-gold" transition={{ type: 'spring', stiffness: 380, damping: 34 }} /> : null}
              <span className="relative z-10 text-base" aria-hidden="true">{tab.icon}</span>
              <span className="relative z-10">{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

function CommandPaletteButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button aria-label="Open search" onClick={() => setOpen(true)} className="fixed bottom-24 right-4 z-30 grid size-14 place-items-center rounded-full bg-sky text-xl font-black text-midnight shadow-glow md:hidden">⌕</button>
      <CommandPalette open={open} onOpenChange={setOpen} />
    </>
  );
}

function CommandPalette({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const commands = useMemo(
    () => [
      { label: 'Plan my day', href: '/plan', keywords: 'trip planner itinerary' },
      { label: 'Show low waits', href: '/live', keywords: 'waits attractions low' },
      { label: 'Route to Magic Kingdom', href: '/routes', keywords: 'transport routes monorail bus' },
      { label: 'Find dinner', href: '/dining', keywords: 'restaurants dining food' },
      { label: 'Open interactive map', href: '/map', keywords: 'map pins nearby' },
      { label: 'Saved favorites', href: '/saved', keywords: 'saved favorites checklist notes' },
      { label: 'Timeline itinerary', href: '/itinerary', keywords: 'timeline day export print' }
    ],
    []
  );
  const filtered = commands.filter((command) => `${command.label} ${command.keywords}`.toLowerCase().includes(query.toLowerCase()));

  useEffect(() => {
    if (!open) setQuery('');
  }, [open]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] bg-black/46 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Search ParkDay">
      <button className="absolute inset-0" aria-label="Close search" onClick={() => onOpenChange(false)} />
      <div className="glass relative mx-auto mt-24 max-w-xl overflow-hidden rounded-[2rem]">
        <div className="border-b border-white/10 p-4">
          <label className="sr-only" htmlFor="command-search">Search ParkDay</label>
          <input
            id="command-search"
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search attractions, dining, routes, commands…"
            className="w-full rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-cream outline-none placeholder:text-cream/40"
          />
        </div>
        <div className="max-h-96 overflow-auto p-3">
          {filtered.map((command) => (
            <button
              key={command.href}
              onClick={() => {
                router.push(command.href);
                onOpenChange(false);
              }}
              className="flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-sm font-bold text-cream/80 hover:bg-white/10"
            >
              <span>{command.label}</span>
              <span className="text-cream/35">↵</span>
            </button>
          ))}
          {!filtered.length ? <p className="px-4 py-8 text-center text-sm text-cream/50">No commands match that search yet.</p> : null}
        </div>
      </div>
    </div>
  );
}
