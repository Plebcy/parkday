'use client';

import { useState } from 'react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/EmptyState';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import { formatDateLabel, formatMinutes } from '@/lib/utils';
import packing from '@/data/seed/packingChecklist.json';

export function SavedHub() {
  const favorites = useParkDayStore((state) => state.favorites);
  const favoriteNames = useParkDayStore((state) => state.favoriteNames);
  const toggleFavorite = useParkDayStore((state) => state.toggleFavorite);
  const savedRoutes = useParkDayStore((state) => state.savedRoutes);
  const removeSavedRoute = useParkDayStore((state) => state.removeSavedRoute);
  const trip = useParkDayStore((state) => state.tripPlan);
  const itinerary = useParkDayStore((state) => state.itinerary);
  const checklistState = useParkDayStore((state) => state.packingChecklist);
  const togglePackingItem = useParkDayStore((state) => state.togglePackingItem);
  const notes = useParkDayStore((state) => state.notes);
  const addNote = useParkDayStore((state) => state.addNote);
  const removeNote = useParkDayStore((state) => state.removeNote);
  const [note, setNote] = useState('');

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Saved" title="Your offline-friendly hub.">
        Favorites, plans, routes, checklist items, and notes are persisted locally for quick access in the park.
      </SectionTitle>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="text-xl font-black text-cream light:text-slate-950">Favorite attractions and restaurants</h2>
          <div className="mt-4 grid gap-2">
            {favorites.length ? favorites.map((id) => <div key={id} className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3"><span className="font-bold text-cream/76 light:text-slate-700">{favoriteNames[id] ?? id}</span><Button variant="ghost" onClick={() => toggleFavorite(id)}>Remove</Button></div>) : <EmptyState title="No favorites yet" body="Tap the heart on waits, dining, and map pins to save items instantly." />}
          </div>
        </Card>
        <Card>
          <h2 className="text-xl font-black text-cream light:text-slate-950">Saved routes</h2>
          <div className="mt-4 grid gap-2">
            {savedRoutes.length ? savedRoutes.map((route) => <div key={route.id} className="rounded-2xl border border-white/10 bg-white/[0.06] p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-black text-cream light:text-slate-950">{route.from} → {route.to}</p><p className="mt-1 text-sm text-cream/56 light:text-slate-600">{formatMinutes(route.route.totalDurationMin)} · {route.route.steps.length} steps</p></div><Button variant="ghost" onClick={() => removeSavedRoute(route.id)}>Remove</Button></div></div>) : <EmptyState title="No saved routes" body="Use the Routes page to save your back-to-hotel and leaving-the-park shortcuts." />}
          </div>
        </Card>
        <Card>
          <h2 className="text-xl font-black text-cream light:text-slate-950">Saved plans</h2>
          {trip ? <div className="mt-4 rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4"><Badge>{formatDateLabel(trip.arrivalDate)}–{formatDateLabel(trip.departureDate)}</Badge><h3 className="mt-3 text-2xl font-black text-cream light:text-slate-950">{trip.name}</h3><p className="mt-2 text-sm text-cream/58 light:text-slate-600">{trip.generatedDays.length} day cards · {trip.parksPlanned.join(', ')}</p></div> : <EmptyState title="No trip plan saved" body="Create a plan from the Trip Planner and it will appear here." />}
          <div className="mt-4 rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4"><p className="font-black text-cream light:text-slate-950">Today timeline</p><p className="mt-1 text-sm text-cream/58 light:text-slate-600">{itinerary.length} itinerary item{itinerary.length === 1 ? '' : 's'} saved.</p></div>
        </Card>
        <Card>
          <h2 className="text-xl font-black text-cream light:text-slate-950">Packing checklist</h2>
          <div className="mt-4 grid gap-2">
            {packing.map((item) => <label key={item.id} className="flex cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-bold text-cream/76 hover:bg-white/10"><input type="checkbox" className="size-5 accent-[#f6d98a]" checked={Boolean(checklistState[item.id])} onChange={() => togglePackingItem(item.id)} /><span>{item.label}</span><Badge className="ml-auto">{item.category}</Badge></label>)}
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <h2 className="text-xl font-black text-cream light:text-slate-950">Notes</h2>
          <form className="mt-4 flex gap-2" onSubmit={(event) => { event.preventDefault(); if (note.trim()) addNote(note.trim()); setNote(''); }}><input className="input" value={note} onChange={(event) => setNote(event.target.value)} placeholder="Stroller parking, allergy reminder, parade spot…" /><Button variant="gold">Add</Button></form>
          <div className="mt-4 grid gap-2 md:grid-cols-2">{notes.map((entry, index) => <div key={`${entry}-${index}`} className="rounded-2xl border border-white/10 bg-white/[0.06] p-4"><p className="text-sm leading-6 text-cream/70 light:text-slate-700">{entry}</p><Button className="mt-3" variant="ghost" onClick={() => removeNote(index)}>Remove</Button></div>)}</div>
        </Card>
      </div>
    </div>
  );
}
