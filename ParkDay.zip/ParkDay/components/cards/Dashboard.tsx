'use client';

import Link from 'next/link';
import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, SectionTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { LinkButton, Button } from '@/components/ui/Button';
import { CardSkeleton } from '@/components/ui/Skeleton';
import { InlineNotice } from '@/components/ui/EmptyState';
import { useParkChildren, useParkLiveData, useParkSchedule, useWdwParks } from '@/hooks/useThemeparks';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import { mergeChildrenWithLiveData } from '@/lib/themeparks/client';
import { formatDateLabel, formatMinutes, todayISO } from '@/lib/utils';
import packing from '@/data/seed/packingChecklist.json';

export function Dashboard() {
  const { data: parks, isLoading, error } = useWdwParks();
  const selectedParkId = useParkDayStore((state) => state.preferences.selectedParkId) ?? parks?.[0]?.id;
  const selectedParkName = useParkDayStore((state) => state.preferences.selectedParkName) ?? parks?.[0]?.name ?? 'Walt Disney World';
  const setSelectedPark = useParkDayStore((state) => state.setSelectedPark);
  const trip = useParkDayStore((state) => state.tripPlan);
  const children = useParkChildren(selectedParkId);
  const live = useParkLiveData(selectedParkId, Boolean(selectedParkId));
  const schedule = useParkSchedule(selectedParkId);
  const favorites = useParkDayStore((state) => state.favorites);
  const checklistState = useParkDayStore((state) => state.packingChecklist);
  const togglePackingItem = useParkDayStore((state) => state.togglePackingItem);

  const attractions = useMemo(() => mergeChildrenWithLiveData(children.data ?? [], live.data ?? [], favorites), [children.data, live.data, favorites]);
  const operating = attractions.filter((item) => item.status === 'OPERATING' && typeof item.waitTime?.standby === 'number');
  const lowWaits = [...operating].sort((a, b) => (a.waitTime?.standby ?? 999) - (b.waitTime?.standby ?? 999)).slice(0, 4);
  const longWaits = [...operating].sort((a, b) => (b.waitTime?.standby ?? -1) - (a.waitTime?.standby ?? -1)).slice(0, 3);
  const down = attractions.filter((item) => item.status === 'DOWN' || item.status === 'CLOSED').slice(0, 4);
  const todaysSchedule = schedule.data?.find((entry) => entry.date === todayISO()) ?? schedule.data?.[0];

  return (
    <div className="space-y-8">
      <section className="grid gap-5 lg:grid-cols-[1.45fr_0.85fr]">
        <Card className="relative min-h-[26rem] overflow-hidden p-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(246,217,138,0.18),transparent_18rem),radial-gradient(circle_at_82%_12%,rgba(112,200,255,0.2),transparent_20rem)]" />
          <div className="relative grid min-h-[26rem] content-between p-6 md:p-8">
            <div className="flex flex-wrap gap-2">
              <Badge>{trip ? `${trip.resort || 'Trip'} saved` : 'Planning mode'}</Badge>
              <Badge>{selectedParkName}</Badge>
              <Badge>Unofficial guide</Badge>
            </div>
            <div>
              <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl text-5xl font-black leading-[0.98] tracking-tight text-cream md:text-7xl light:text-slate-950">
                Make your park day feel easy.
              </motion.h1>
              <p className="mt-5 max-w-2xl text-base leading-7 text-cream/70 light:text-slate-650 md:text-lg">
                Plan the big choices before you go, then use live waits, saved routes, dining notes, and offline-friendly checklists when the day gets loud.
              </p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <LinkButton href="/itinerary" variant="gold">Build itinerary</LinkButton>
              <LinkButton href="/live" variant="primary">Check waits</LinkButton>
              <LinkButton href="/routes">Find route</LinkButton>
              <LinkButton href="/dining">Browse dining</LinkButton>
              <LinkButton href="/saved">Save favorites</LinkButton>
            </div>
          </div>
        </Card>
        <div className="grid gap-5">
          <Card>
            <p className="text-xs font-extrabold uppercase tracking-[0.22em] text-gold/80">Trip pulse</p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <Metric label="Countdown" value={trip?.arrivalDate ? countdown(trip.arrivalDate) : 'Set trip'} />
              <Metric label="Recommended" value={selectedParkName.replace('Disney\'s ', '')} small />
              <Metric label="Park hours" value={todaysSchedule?.openingTime && todaysSchedule.closingTime ? `${timeShort(todaysSchedule.openingTime)}–${timeShort(todaysSchedule.closingTime)}` : 'Unavailable'} small />
              <Metric label="Last update" value={live.dataUpdatedAt ? new Date(live.dataUpdatedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : 'Not yet'} small />
            </div>
            <p className="mt-4 text-xs leading-5 text-cream/52 light:text-slate-600">Park hours and waits come from ThemeParks.wiki when available. The app will show unavailable states instead of pretending.</p>
          </Card>
          <Card>
            <p className="mb-3 text-sm font-black text-cream light:text-slate-950">Park selector</p>
            <div className="grid gap-2">
              {isLoading ? <CardSkeleton /> : parks?.slice(0, 6).map((park) => (
                <button key={park.id} onClick={() => setSelectedPark(park.id, park.name)} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-left text-sm font-bold text-cream/78 hover:bg-white/10">
                  <span>{park.name}</span>
                  {selectedParkId === park.id ? <span className="text-gold">Selected</span> : <span className="text-cream/35">Choose</span>}
                </button>
              ))}
              {error ? <InlineNotice>ThemeParks.wiki did not load. The rest of ParkDay still works with saved plans and seed data.</InlineNotice> : null}
            </div>
          </Card>
        </div>
      </section>

      <section className="grid gap-5 lg:grid-cols-3">
        <LiveSummary title="Low waits right now" items={lowWaits.map((item) => ({ label: item.name, value: formatMinutes(item.waitTime?.standby ?? 0) }))} loading={live.isLoading || children.isLoading} empty="No current low-wait data yet." />
        <LiveSummary title="Longest waits" items={longWaits.map((item) => ({ label: item.name, value: formatMinutes(item.waitTime?.standby ?? 0) }))} loading={live.isLoading || children.isLoading} empty="No current wait data yet." />
        <LiveSummary title="Closed or down" items={down.map((item) => ({ label: item.name, value: item.status ?? 'Unknown' }))} loading={live.isLoading || children.isLoading} empty="No down attractions reported in the current feed." />
      </section>

      <section className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
        <Card>
          <SectionTitle eyebrow="Smart day checklist" title="Small prep, calmer day." />
          <div className="grid gap-2">
            {packing.slice(0, 8).map((item) => (
              <label key={item.id} className="flex cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-bold text-cream/76 hover:bg-white/10">
                <input type="checkbox" checked={Boolean(checklistState[item.id])} onChange={() => togglePackingItem(item.id)} className="size-5 accent-[#f6d98a]" />
                <span>{item.label}</span>
              </label>
            ))}
          </div>
        </Card>
        <Card>
          <SectionTitle eyebrow="Dashboard preview" title="Everything you need in one rhythm.">
            Desktop feels like a planning dashboard; mobile keeps the important controls under your thumb.
          </SectionTitle>
          <div className="grid gap-4 md:grid-cols-3">
            <Preview href="/routes" title="Best route from here" body="Seeded transportation graph with accessible route notes and estimated times." />
            <Preview href="/dining" title="Find food near me" body="Filter by style, price, dietary tags, and reservation reminders." />
            <Preview href="/itinerary" title="Add a little buffer" body="Timeline warnings for overlap, route time, and too much walking." />
          </div>
          <div className="mt-5 rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-black text-cream light:text-slate-950">What can I do in the next 45 minutes?</p>
                <p className="mt-1 text-sm text-cream/58 light:text-slate-600">Uses low waits + saved location placeholder. Ready for real coordinates later.</p>
              </div>
              <LinkButton href="/live" variant="gold">Open waits</LinkButton>
            </div>
          </div>
        </Card>
      </section>
    </div>
  );
}

function Metric({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.07] p-4">
      <p className="text-xs font-bold uppercase tracking-[0.16em] text-cream/44 light:text-slate-500">{label}</p>
      <p className={small ? 'mt-2 text-lg font-black text-cream light:text-slate-950' : 'mt-2 text-2xl font-black text-cream light:text-slate-950'}>{value}</p>
    </div>
  );
}

function LiveSummary({ title, items, loading, empty }: { title: string; items: { label: string; value: string }[]; loading: boolean; empty: string }) {
  return (
    <Card>
      <h3 className="text-lg font-black text-cream light:text-slate-950">{title}</h3>
      <div className="mt-4 space-y-3">
        {loading ? <><CardSkeleton /><CardSkeleton /></> : items.length ? items.map((item) => (
          <div key={`${item.label}-${item.value}`} className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3">
            <p className="line-clamp-1 text-sm font-bold text-cream/78 light:text-slate-700">{item.label}</p>
            <motion.span key={item.value} initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="rounded-full bg-sky/16 px-3 py-1 text-sm font-black text-sky">{item.value}</motion.span>
          </div>
        )) : <p className="rounded-2xl border border-white/10 bg-white/[0.06] p-4 text-sm text-cream/58 light:text-slate-600">{empty}</p>}
      </div>
    </Card>
  );
}

function Preview({ href, title, body }: { href: string; title: string; body: string }) {
  return (
    <Link href={href} className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4 transition hover:-translate-y-1 hover:bg-white/10">
      <div className="mb-8 grid size-10 place-items-center rounded-2xl bg-gold/16 text-gold">✦</div>
      <h3 className="font-black text-cream light:text-slate-950">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-cream/58 light:text-slate-600">{body}</p>
    </Link>
  );
}

function countdown(date: string) {
  const diff = new Date(`${date}T12:00:00`).getTime() - new Date().getTime();
  const days = Math.ceil(diff / 86_400_000);
  if (days < 0) return 'Today mode';
  if (days === 0) return 'Today';
  return `${days} day${days === 1 ? '' : 's'}`;
}

function timeShort(value?: string) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value.slice(11, 16) || value;
  return parsed.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}
