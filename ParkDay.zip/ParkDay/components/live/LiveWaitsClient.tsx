'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/Badge';
import { BottomSheet } from '@/components/ui/BottomSheet';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { EmptyState, InlineNotice } from '@/components/ui/EmptyState';
import { CardSkeleton } from '@/components/ui/Skeleton';
import { useParkChildren, useParkLiveData, useWdwParks } from '@/hooks/useThemeparks';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import { mergeChildrenWithLiveData } from '@/lib/themeparks/client';
import type { Attraction, WaitSort } from '@/lib/types';
import { formatMinutes } from '@/lib/utils';

const filters = ['Open now', 'Low waits', 'Thrill', 'Family', 'Shows', 'Dining', 'Indoor', 'Height requirement', 'Favorites'];

export function LiveWaitsClient() {
  const { data: parks, isLoading: parksLoading, error: parksError } = useWdwParks();
  const selectedParkId = useParkDayStore((state) => state.preferences.selectedParkId) ?? parks?.[0]?.id;
  const selectedParkName = useParkDayStore((state) => state.preferences.selectedParkName) ?? parks?.[0]?.name;
  const setSelectedPark = useParkDayStore((state) => state.setSelectedPark);
  const favorites = useParkDayStore((state) => state.favorites);
  const toggleFavorite = useParkDayStore((state) => state.toggleFavorite);
  const addItineraryItem = useParkDayStore((state) => state.addItineraryItem);
  const [query, setQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState<string[]>(['Open now']);
  const [sort, setSort] = useState<WaitSort>('lowest');
  const [selected, setSelected] = useState<Attraction | null>(null);
  const children = useParkChildren(selectedParkId);
  const live = useParkLiveData(selectedParkId, Boolean(selectedParkId));

  const attractions = useMemo(() => mergeChildrenWithLiveData(children.data ?? [], live.data ?? [], favorites), [children.data, live.data, favorites]);
  const filtered = useMemo(() => applyFilters(attractions, query, activeFilters, sort), [attractions, query, activeFilters, sort]);
  const loading = parksLoading || children.isLoading || live.isLoading;

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Live wait times" title="Low waits, closures, and the next good move.">
        Live data refreshes responsibly while this page is visible. Last updated: {live.dataUpdatedAt ? new Date(live.dataUpdatedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : 'not yet'}.
      </SectionTitle>

      <Card>
        <div className="grid gap-4 lg:grid-cols-[18rem_1fr]">
          <div>
            <label className="mb-2 block text-sm font-bold text-cream/70">Park</label>
            <select className="input" value={selectedParkId ?? ''} onChange={(event) => {
              const park = parks?.find((item) => item.id === event.target.value);
              if (park) setSelectedPark(park.id, park.name);
            }}>
              {parks?.map((park) => <option key={park.id} value={park.id}>{park.name}</option>)}
            </select>
          </div>
          <div className="grid gap-3 md:grid-cols-[1fr_auto]">
            <div>
              <label className="mb-2 block text-sm font-bold text-cream/70" htmlFor="wait-search">Search</label>
              <input id="wait-search" className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search attractions, shows, dining…" />
            </div>
            <div>
              <label className="mb-2 block text-sm font-bold text-cream/70">Sort</label>
              <select className="input" value={sort} onChange={(event) => setSort(event.target.value as WaitSort)}>
                <option value="lowest">Lowest wait</option>
                <option value="highest">Highest wait</option>
                <option value="alpha">Alphabetical</option>
                <option value="nearby">Nearby placeholder</option>
                <option value="changed">Recently changed</option>
              </select>
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {filters.map((filter) => {
            const active = activeFilters.includes(filter);
            return <button key={filter} onClick={() => setActiveFilters((current) => current.includes(filter) ? current.filter((item) => item !== filter) : [...current, filter])} className={`rounded-full border px-4 py-2 text-sm font-bold transition ${active ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/70 hover:bg-white/10'}`}>{filter}</button>;
          })}
          <Button onClick={() => live.refetch()} variant="secondary">Refresh</Button>
        </div>
      </Card>

      {parksError || live.error ? <InlineNotice>Live data is unavailable right now. Saved plans and seed data still work; ParkDay will retry when the page is active.</InlineNotice> : null}

      {loading ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3"><CardSkeleton /><CardSkeleton /><CardSkeleton /><CardSkeleton /><CardSkeleton /><CardSkeleton /></div> : filtered.length ? (
        <motion.div layout className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((attraction) => (
            <AttractionCard key={attraction.id} attraction={attraction} onSelect={() => setSelected(attraction)} onFavorite={() => toggleFavorite(attraction.id, attraction.name)} onAdd={() => addItineraryItem({ type: 'attraction', title: attraction.name, park: selectedParkName, startTime: '10:00', endTime: '10:30', notes: `Current status: ${attraction.status ?? 'Unknown'}`, sourceId: attraction.id })} />
          ))}
        </motion.div>
      ) : <EmptyState title="Nothing matches those filters" body="Try clearing filters or switching parks. If the live feed is quiet, ParkDay will show real empty states instead of filling in guesses." />}

      <BottomSheet open={Boolean(selected)} onClose={() => setSelected(null)} title={selected?.name ?? 'Attraction details'} footer={selected ? <div className="grid grid-cols-2 gap-3"><Button variant="gold" onClick={() => { addItineraryItem({ type: 'attraction', title: selected.name, park: selectedParkName, startTime: '10:00', endTime: '10:30', notes: `Added from live waits. Status: ${selected.status ?? 'Unknown'}`, sourceId: selected.id }); setSelected(null); }}>Add to plan</Button><Button onClick={() => setSelected(null)}>Get route</Button></div> : null}>
        {selected ? <AttractionDetails attraction={selected} /> : null}
      </BottomSheet>
    </div>
  );
}

function AttractionCard({ attraction, onSelect, onFavorite, onAdd }: { attraction: Attraction; onSelect: () => void; onFavorite: () => void; onAdd: () => void }) {
  const wait = typeof attraction.waitTime?.standby === 'number' ? formatMinutes(attraction.waitTime.standby) : '—';
  return (
    <motion.article layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass card-hover rounded-[2rem] p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <Badge className={statusColor(attraction.status)}>{labelStatus(attraction.status)}</Badge>
          <h3 className="mt-3 text-lg font-black leading-tight text-cream light:text-slate-950">{attraction.name}</h3>
          <p className="mt-1 text-sm text-cream/50 light:text-slate-600">{attraction.land ?? attraction.thrillLevel ?? 'Attraction'}</p>
        </div>
        <button aria-label={attraction.isFavorite ? 'Remove favorite' : 'Save favorite'} onClick={onFavorite} className="grid size-11 place-items-center rounded-2xl border border-white/10 bg-white/10 text-xl transition active:scale-90">{attraction.isFavorite ? '♥' : '♡'}</button>
      </div>
      <div className="mt-5 flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-cream/44">Current wait</p>
          <motion.p key={wait} initial={{ scale: 0.92 }} animate={{ scale: 1 }} className="mt-1 text-4xl font-black text-sky">{wait}</motion.p>
        </div>
        <div className="h-12 w-28 rounded-2xl border border-white/10 bg-white/[0.06] p-2" aria-label="Wait history sparkline placeholder">
          <svg viewBox="0 0 100 28" className="h-full w-full" role="img" aria-label="Future historical waits placeholder"><path d="M2 21 C 18 8, 24 10, 34 17 S 54 28, 68 10 S 86 6, 98 14" fill="none" stroke="currentColor" strokeWidth="4" className="text-gold/60" strokeLinecap="round" /></svg>
        </div>
      </div>
      <div className="mt-5 grid grid-cols-2 gap-2">
        <Button onClick={onSelect}>Details</Button>
        <Button onClick={onAdd} variant="gold">Add</Button>
      </div>
    </motion.article>
  );
}

function AttractionDetails({ attraction }: { attraction: Attraction }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Detail label="Wait" value={typeof attraction.waitTime?.standby === 'number' ? formatMinutes(attraction.waitTime.standby) : 'Unavailable'} />
        <Detail label="Status" value={labelStatus(attraction.status)} />
        <Detail label="Type" value={attraction.thrillLevel ?? 'Attraction'} />
        <Detail label="Indoor" value={attraction.indoor ? 'Likely' : 'Unknown'} />
      </div>
      <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4">
        <p className="text-sm font-black text-cream light:text-slate-950">Notes</p>
        <p className="mt-2 text-sm leading-6 text-cream/62 light:text-slate-600">Height requirements, land, showtimes, and dining data are normalized when the source provides them. Missing fields are left blank instead of guessed.</p>
      </div>
      <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4">
        <p className="text-sm font-black text-cream light:text-slate-950">Future history</p>
        <p className="mt-2 text-sm leading-6 text-cream/62 light:text-slate-600">Mini sparkline is a placeholder for historical wait collection. Add a worker or database later if you want reliable trends.</p>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4"><p className="text-xs font-bold uppercase tracking-[0.18em] text-cream/44">{label}</p><p className="mt-2 text-lg font-black text-cream light:text-slate-950">{value}</p></div>;
}

function applyFilters(attractions: Attraction[], query: string, activeFilters: string[], sort: WaitSort) {
  let next = attractions.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()));
  if (activeFilters.includes('Open now')) next = next.filter((item) => item.status === 'OPERATING');
  if (activeFilters.includes('Low waits')) next = next.filter((item) => typeof item.waitTime?.standby === 'number' && item.waitTime.standby <= 30);
  if (activeFilters.includes('Thrill')) next = next.filter((item) => item.thrillLevel === 'high');
  if (activeFilters.includes('Family')) next = next.filter((item) => item.familyFriendly);
  if (activeFilters.includes('Indoor')) next = next.filter((item) => item.indoor);
  if (activeFilters.includes('Favorites')) next = next.filter((item) => item.isFavorite);
  next = [...next];
  if (sort === 'lowest') next.sort((a, b) => (a.waitTime?.standby ?? 999) - (b.waitTime?.standby ?? 999));
  if (sort === 'highest') next.sort((a, b) => (b.waitTime?.standby ?? -1) - (a.waitTime?.standby ?? -1));
  if (sort === 'alpha') next.sort((a, b) => a.name.localeCompare(b.name));
  if (sort === 'changed') next.sort((a, b) => (b.lastUpdated ?? '').localeCompare(a.lastUpdated ?? ''));
  return next;
}

function labelStatus(status?: string) {
  if (!status) return 'Unknown';
  return status.toLowerCase().replace(/_/g, ' ').replace(/^\w/, (letter) => letter.toUpperCase());
}

function statusColor(status?: string) {
  if (status === 'OPERATING') return 'border-emerald-300/30 bg-emerald-400/15 text-emerald-100';
  if (status === 'DOWN') return 'border-red-300/30 bg-red-400/15 text-red-100';
  if (status === 'CLOSED') return 'border-white/10 bg-white/10 text-cream/60';
  return '';
}
