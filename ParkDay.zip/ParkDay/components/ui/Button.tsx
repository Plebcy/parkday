import { ButtonHTMLAttributes, AnchorHTMLAttributes, ReactNode } from 'react';
import Link from 'next/link';
import { cn } from '@/lib/utils';

type Variant = 'primary' | 'secondary' | 'ghost' | 'gold' | 'danger';
const styles: Record<Variant, string> = {
  primary: 'bg-sky/90 text-midnight shadow-glow hover:bg-sky',
  secondary: 'border border-white/15 bg-white/10 text-cream hover:bg-white/16',
  ghost: 'text-cream/80 hover:bg-white/10 hover:text-cream',
  gold: 'bg-gold text-midnight hover:bg-[#ffe5a4]',
  danger: 'border border-red-300/30 bg-red-500/15 text-red-100 hover:bg-red-500/24'
};

export function Button({ className, variant = 'secondary', ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      className={cn(
        'inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-4 py-2 text-sm font-bold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50',
        styles[variant],
        className
      )}
      {...props}
    />
  );
}

export function LinkButton({ className, variant = 'secondary', href, children, ...props }: AnchorHTMLAttributes<HTMLAnchorElement> & { href: string; variant?: Variant; children: ReactNode }) {
  return (
    <Link
      href={href}
      className={cn(
        'inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-4 py-2 text-sm font-bold transition active:scale-[0.98]',
        styles[variant],
        className
      )}
      {...props}
    >
      {children}
    </Link>
  );
}
