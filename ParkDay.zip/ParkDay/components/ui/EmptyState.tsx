import { ReactNode } from 'react';
import { Button } from './Button';

export function EmptyState({ title, body, actionLabel, onAction }: { title: string; body: string; actionLabel?: string; onAction?: () => void }) {
  return (
    <div className="rounded-[2rem] border border-dashed border-white/18 bg-white/[0.06] p-8 text-center">
      <div className="mx-auto mb-4 grid size-12 place-items-center rounded-2xl bg-gold/18 text-2xl" aria-hidden="true">✦</div>
      <h3 className="text-lg font-black text-cream light:text-slate-950">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-cream/64 light:text-slate-600">{body}</p>
      {actionLabel && onAction ? <Button className="mt-5" variant="gold" onClick={onAction}>{actionLabel}</Button> : null}
    </div>
  );
}

export function InlineNotice({ children }: { children: ReactNode }) {
  return <p className="rounded-2xl border border-gold/20 bg-gold/10 px-4 py-3 text-sm leading-6 text-gold/90">{children}</p>;
}
