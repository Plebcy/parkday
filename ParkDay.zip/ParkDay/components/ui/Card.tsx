import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('glass card-hover rounded-[2rem] p-5 md:p-6', className)} {...props} />;
}

export function CardHeader({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('mb-4 flex items-start justify-between gap-4', className)} {...props} />;
}

export function SectionTitle({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <div className="mb-5">
      {eyebrow ? <p className="mb-2 text-xs font-extrabold uppercase tracking-[0.24em] text-gold/80">{eyebrow}</p> : null}
      <h2 className="text-2xl font-black tracking-tight text-cream md:text-3xl light:text-slate-950">{title}</h2>
      {children ? <p className="mt-2 max-w-2xl text-sm leading-6 text-cream/65 light:text-slate-600">{children}</p> : null}
    </div>
  );
}
