import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

export function Badge({ className, ...props }: HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn('inline-flex items-center rounded-full border border-white/12 bg-white/10 px-3 py-1 text-xs font-bold text-cream/78 light:border-slate-900/10 light:bg-slate-900/5 light:text-slate-700', className)} {...props} />;
}
