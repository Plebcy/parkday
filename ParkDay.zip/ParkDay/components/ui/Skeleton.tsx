import { cn } from '@/lib/utils';

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton rounded-2xl', className)} aria-hidden="true" />;
}

export function CardSkeleton() {
  return (
    <div className="glass rounded-[2rem] p-5">
      <Skeleton className="mb-4 h-5 w-2/3" />
      <Skeleton className="mb-3 h-10 w-1/2" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="mt-2 h-4 w-5/6" />
    </div>
  );
}
