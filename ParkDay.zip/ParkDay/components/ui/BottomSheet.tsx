'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { ReactNode, useEffect } from 'react';
import { Button } from './Button';

export function BottomSheet({ open, title, children, onClose, footer }: { open: boolean; title: string; children: ReactNode; onClose: () => void; footer?: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div className="fixed inset-0 z-50 flex items-end justify-center bg-black/46 p-0 md:items-center md:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} role="dialog" aria-modal="true" aria-label={title}>
          <button className="absolute inset-0 cursor-default" onClick={onClose} aria-label="Close sheet" />
          <motion.div
            initial={{ y: 80, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 80, opacity: 0, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 260, damping: 28 }}
            className="glass relative max-h-[88vh] w-full overflow-hidden rounded-t-[2rem] md:max-w-2xl md:rounded-[2rem]"
          >
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/10 bg-midnight/70 px-5 py-4 backdrop-blur-xl">
              <div>
                <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-white/22 md:hidden" />
                <h2 className="text-lg font-black text-cream">{title}</h2>
              </div>
              <Button variant="ghost" onClick={onClose} aria-label="Close">✕</Button>
            </div>
            <div className="max-h-[64vh] overflow-auto p-5">{children}</div>
            {footer ? <div className="sticky bottom-0 border-t border-white/10 bg-midnight/75 p-4 backdrop-blur-xl">{footer}</div> : null}
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
