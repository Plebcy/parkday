'use client';

import { FormEvent, useMemo, useState } from 'react';
import { Card, SectionTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import type { Pace, PlannedBlock, TripPlan, TransportMode } from '@/lib/types';
import { dateRange, downloadTextFile, formatDateLabel, todayISO, uid } from '@/lib/utils';
import resorts from '@/data/seed/resorts.json';
import parks from '@/data/seed/parks.json';
import templates from '@/data/seed/planningTemplates.json';

const priorities = ['Thrill rides', 'Characters', 'Shows', 'Food', 'Low walking', 'Young kids', 'Accessibility', 'Nighttime spectaculars'];
const budgets = ['Quick service', 'Table service', 'Snacks', 'Character dining'];
const transports: TransportMode[] = ['bus', 'monorail', 'skyliner', 'boat', 'walk', 'rideshare', 'car'];

export function TripPlanner() {
  const saved = useParkDayStore((state) => state.tripPlan);
  const saveTripPlan = useParkDayStore((state) => state.saveTripPlan);
  const [arrivalDate, setArrivalDate] = useState(saved?.arrivalDate ?? todayISO());
  const [departureDate, setDepartureDate] = useState(saved?.departureDate ?? todayISO());
  const [resort, setResort] = useState(saved?.resort ?? '');
  const [partySize, setPartySize] = useState(saved?.partySize ?? 4);
  const [ages, setAges] = useState(saved?.ages ?? 'Adults, teens, kids');
  const [mobilityNeeds, setMobilityNeeds] = useState(saved?.mobilityNeeds ?? '');
  const [parksPlanned, setParksPlanned] = useState<string[]>(saved?.parksPlanned ?? ['Magic Kingdom', 'EPCOT']);
  const [selectedPriorities, setSelectedPriorities] = useState<string[]>(saved?.priorities ?? ['Low walking', 'Food']);
  const [pace, setPace] = useState<Pace>(saved?.pace ?? 'balanced');
  const [budgetPreferences, setBudgetPreferences] = useState<string[]>(saved?.budgetPreferences ?? ['Quick service', 'Snacks']);
  const [transportationPreferences, setTransportationPreferences] = useState<TransportMode[]>(saved?.transportationPreferences ?? ['bus', 'skyliner', 'monorail']);
  const [preview, setPreview] = useState<TripPlan | undefined>(saved);

  const dayCount = useMemo(() => dateRange(arrivalDate, departureDate).length, [arrivalDate, departureDate]);

  function submit(event: FormEvent) {
    event.preventDefault();
    const plan = generatePlan({ arrivalDate, departureDate, resort, partySize, ages, mobilityNeeds, parksPlanned, priorities: selectedPriorities, pace, budgetPreferences, transportationPreferences });
    saveTripPlan(plan);
    setPreview(plan);
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[18rem_1fr]">
      <aside className="no-print lg:sticky lg:top-28 lg:self-start">
        <Card>
          <p className="text-sm font-black text-cream light:text-slate-950">Planning shortcuts</p>
          <div className="mt-4 grid gap-2">
            {['Dates', 'Party', 'Parks', 'Priorities', 'Output'].map((item) => <a key={item} href={`#${item.toLowerCase()}`} className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-bold text-cream/72 hover:bg-white/10">{item}</a>)}
          </div>
          <p className="mt-4 text-xs leading-5 text-cream/48 light:text-slate-600">Plans are rule-based and saved locally. No AI badge, no fake certainty.</p>
        </Card>
      </aside>
      <div className="space-y-6">
        <SectionTitle eyebrow="Trip planner" title="Build a day-by-day plan that survives real park chaos.">
          Choose the shape of your trip, then ParkDay creates human-designed blocks with travel notes, breaks, and dining windows.
        </SectionTitle>
        <form onSubmit={submit} className="grid gap-6">
          <Card id="dates">
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Dates and stay</h2>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Arrival date"><input type="date" value={arrivalDate} onChange={(e) => setArrivalDate(e.target.value)} required className="input" /></Field>
              <Field label="Departure date"><input type="date" value={departureDate} onChange={(e) => setDepartureDate(e.target.value)} required className="input" /></Field>
              <Field label="Resort / hotel"><select value={resort} onChange={(e) => setResort(e.target.value)} className="input"><option value="">Choose a resort</option>{resorts.map((item) => <option key={item.id} value={item.name}>{item.name}</option>)}</select></Field>
              <Field label="Party size"><input type="number" min={1} max={20} value={partySize} onChange={(e) => setPartySize(Number(e.target.value))} className="input" /></Field>
            </div>
          </Card>
          <Card id="party">
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Party needs</h2>
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Ages / group notes"><textarea value={ages} onChange={(e) => setAges(e.target.value)} className="input min-h-28" /></Field>
              <Field label="Mobility and accessibility notes"><textarea value={mobilityNeeds} onChange={(e) => setMobilityNeeds(e.target.value)} className="input min-h-28" placeholder="Wheelchair, stroller, heat sensitivity, sensory breaks…" /></Field>
            </div>
          </Card>
          <Card id="parks">
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Parks planned</h2>
            <ToggleGrid items={[...parks.map((item) => item.name), 'Typhoon Lagoon', 'Blizzard Beach']} selected={parksPlanned} onToggle={(item) => toggle(item, parksPlanned, setParksPlanned)} />
          </Card>
          <Card id="priorities">
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Priorities and pace</h2>
            <div className="grid gap-6">
              <div><p className="mb-3 text-sm font-bold text-cream/70">Priorities</p><ToggleGrid items={priorities} selected={selectedPriorities} onToggle={(item) => toggle(item, selectedPriorities, setSelectedPriorities)} /></div>
              <div><p className="mb-3 text-sm font-bold text-cream/70">Pace</p><div className="grid gap-2 md:grid-cols-3">{(['relaxed', 'balanced', 'maximize'] as Pace[]).map((item) => <button type="button" key={item} onClick={() => setPace(item)} className={`rounded-2xl border px-4 py-3 text-sm font-black capitalize ${pace === item ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/70'}`}>{item === 'maximize' ? 'Maximize attractions' : item}</button>)}</div></div>
              <div><p className="mb-3 text-sm font-bold text-cream/70">Budget preferences</p><ToggleGrid items={budgets} selected={budgetPreferences} onToggle={(item) => toggle(item, budgetPreferences, setBudgetPreferences)} /></div>
              <div><p className="mb-3 text-sm font-bold text-cream/70">Transportation preferences</p><ToggleGrid items={transports} selected={transportationPreferences} onToggle={(item) => toggle(item, transportationPreferences, setTransportationPreferences)} titleCase /></div>
            </div>
          </Card>
          <div className="no-print flex flex-wrap gap-3">
            <Button type="submit" variant="gold">Create / update plan</Button>
            {preview ? <Button type="button" onClick={() => downloadTextFile('parkday-trip-plan.json', JSON.stringify(preview, null, 2))}>Export JSON</Button> : null}
            {preview ? <Button type="button" onClick={() => window.print()}>Print-friendly view</Button> : null}
            {preview && typeof navigator !== 'undefined' && 'share' in navigator ? <Button type="button" onClick={() => navigator.share({ title: 'ParkDay itinerary', text: `${preview.name} — ${preview.generatedDays.length} days planned.` }).catch(() => undefined)}>Share</Button> : null}
          </div>
        </form>
        <section id="output">
          {preview ? <PlanOutput plan={preview} /> : <EmptyState title="No plan yet" body="Fill in the basics and ParkDay will create day cards with morning, afternoon, and evening blocks." />}
        </section>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="grid gap-2 text-sm font-bold text-cream/70 light:text-slate-700"><span>{label}</span>{children}</label>;
}

function ToggleGrid<T extends string>({ items, selected, onToggle, titleCase }: { items: T[]; selected: string[]; onToggle: (item: T) => void; titleCase?: boolean }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item) => {
        const active = selected.includes(item);
        return <button type="button" key={item} onClick={() => onToggle(item)} className={`rounded-full border px-4 py-2 text-sm font-bold transition ${active ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/70 hover:bg-white/10'}`}>{titleCase ? item.replace('-', ' ') : item}</button>;
      })}
    </div>
  );
}

function toggle<T extends string>(item: T, selected: string[], setSelected: (items: T[]) => void) {
  setSelected((selected.includes(item) ? selected.filter((entry) => entry !== item) : [...selected, item]) as T[]);
}

function PlanOutput({ plan }: { plan: TripPlan }) {
  return (
    <div className="space-y-5">
      <SectionTitle eyebrow="Planner output" title={plan.name}>
        {formatDateLabel(plan.arrivalDate)}–{formatDateLabel(plan.departureDate)} · {plan.partySize} guests · {plan.pace === 'maximize' ? 'Maximize attractions' : `${plan.pace} pace`}
      </SectionTitle>
      <div className="grid gap-5">
        {plan.generatedDays.map((day) => (
          <Card key={day.id} className="print-card">
            <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
              <div>
                <Badge>{formatDateLabel(day.date)}</Badge>
                <h3 className="mt-3 text-2xl font-black text-cream light:text-slate-950">{day.park}</h3>
                <p className="mt-1 text-sm text-cream/58 light:text-slate-600">Suggested arrival: {day.arrivalTime}</p>
              </div>
              <Badge>{day.notes[0]}</Badge>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {day.blocks.map((block) => <BlockCard key={block.id} block={block} />)}
            </div>
            <ul className="mt-5 grid gap-2 text-sm text-cream/62 light:text-slate-600 md:grid-cols-2">
              {day.notes.slice(1).map((note) => <li key={note} className="rounded-2xl bg-white/[0.06] px-4 py-3">{note}</li>)}
            </ul>
          </Card>
        ))}
      </div>
    </div>
  );
}

function BlockCard({ block }: { block: PlannedBlock }) {
  return (
    <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4">
      <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-gold/80">{block.label}</p>
      <h4 className="mt-2 font-black text-cream light:text-slate-950">{block.title}</h4>
      <ul className="mt-3 space-y-2 text-sm leading-6 text-cream/62 light:text-slate-600">
        {block.items.map((item) => <li key={item}>• {item}</li>)}
      </ul>
      {block.travelNote ? <p className="mt-3 rounded-2xl bg-sky/10 px-3 py-2 text-xs font-bold text-sky">{block.travelNote}</p> : null}
    </div>
  );
}

function generatePlan(input: Omit<TripPlan, 'id' | 'name' | 'generatedDays' | 'updatedAt'>): TripPlan {
  const days = dateRange(input.arrivalDate, input.departureDate);
  const selectedParks = input.parksPlanned.length ? input.parksPlanned : ['Magic Kingdom'];
  const generatedDays = days.map((date, index) => {
    const park = selectedParks[index % selectedParks.length];
    const template = templates.find((item) => item.park === park && (item.pace === input.pace || input.priorities.includes('Low walking'))) ?? templates[index % templates.length];
    const defaultPark = parks.find((item) => item.name === park);
    const arrivalTime = input.pace === 'relaxed' ? '09:30' : input.pace === 'maximize' ? defaultPark?.defaultArrival ?? '08:00' : template.arrivalTime;
    return {
      id: uid('day'),
      date,
      park,
      arrivalTime,
      blocks: template.blocks.map((block, blockIndex) => ({
        id: uid('block'),
        label: block.label as PlannedBlock['label'],
        title: adaptTitle(block.title, input),
        items: adaptItems(block.items, input, blockIndex),
        travelNote: blockIndex === 0 ? `Leave ${input.resort || 'your hotel'} with at least ${input.pace === 'maximize' ? 60 : 45} minutes of transportation buffer.` : undefined
      })),
      notes: buildNotes(input, park)
    };
  });
  return {
    ...input,
    id: savedId(input),
    name: `${input.resort || 'WDW'} trip plan`,
    generatedDays,
    updatedAt: new Date().toISOString()
  };
}

function adaptTitle(title: string, input: Pick<TripPlan, 'priorities' | 'pace'>) {
  if (input.priorities.includes('Young kids')) return title.replace('headliners', 'nearby family wins');
  if (input.priorities.includes('Low walking')) return title.replace('two nearby', 'one area of');
  return title;
}

function adaptItems(items: string[], input: Pick<TripPlan, 'priorities' | 'budgetPreferences' | 'mobilityNeeds'>, blockIndex: number) {
  const next = [...items];
  if (input.priorities.includes('Food') && blockIndex === 1) next.push(input.budgetPreferences.includes('Table service') ? 'Hold a table-service lunch window' : 'Use mobile order before peak lunch');
  if (input.mobilityNeeds) next.push('Add accessibility buffer and rest seating to this block');
  if (input.priorities.includes('Nighttime spectaculars') && blockIndex === 2) next.push('Choose a viewing spot based on your exit route');
  return next;
}

function buildNotes(input: Pick<TripPlan, 'priorities' | 'transportationPreferences' | 'pace'>, park: string) {
  const notes = ['Editable seed plan'];
  if (input.priorities.includes('Low walking')) notes.push('Keep attractions clustered by land; avoid crisscrossing the park.');
  if (input.priorities.includes('Young kids')) notes.push('Protect a shaded snack break and avoid stacking two long queues.');
  if (input.transportationPreferences.includes('rideshare')) notes.push('Rideshare can help at night, but confirm pickup zones before leaving.');
  notes.push(`Add a route estimate before leaving ${park}.`);
  notes.push(input.pace === 'maximize' ? 'Use early morning for headliners and add buffers later.' : 'A calmer plan usually beats one extra attraction.');
  return notes;
}

function savedId(input: Pick<TripPlan, 'arrivalDate' | 'departureDate'>) {
  return `trip-${input.arrivalDate}-${input.departureDate}`;
}
