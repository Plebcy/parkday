'use client';

import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card, SectionTitle } from '@/components/ui/Card';
import { EmptyState, InlineNotice } from '@/components/ui/EmptyState';
import type { CalculatedRoute, TransportMode } from '@/lib/types';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';
import { calculateAlternativeRoutes } from '@/lib/transport/dijkstra';
import { transportNodes, type RoutePreferences } from '@/lib/transport/graph';
import { formatMinutes } from '@/lib/utils';

const preferenceOptions = [
  { id: 'fewestTransfers', label: 'Fewest transfers' },
  { id: 'fastest', label: 'Fastest' },
  { id: 'leastWalking', label: 'Least walking' },
  { id: 'avoidBoats', label: 'Avoid boats' },
  { id: 'avoidSkyliner', label: 'Avoid Skyliner' },
  { id: 'accessible', label: 'Accessible route' },
  { id: 'strollerFriendly', label: 'Stroller-friendly' }
] as const;

export function RoutePlanner() {
  const [from, setFrom] = useState('pop-century');
  const [to, setTo] = useState('mk');
  const [timeMode, setTimeMode] = useState('Leave now');
  const [selectedPrefs, setSelectedPrefs] = useState<string[]>(['fastest']);
  const [chosen, setChosen] = useState<CalculatedRoute | null>(null);
  const saveRoute = useParkDayStore((state) => state.saveRoute);
  const addItineraryItem = useParkDayStore((state) => state.addItineraryItem);

  const preferences = useMemo<RoutePreferences>(() => ({
    fastest: selectedPrefs.includes('fastest'),
    fewestTransfers: selectedPrefs.includes('fewestTransfers'),
    leastWalking: selectedPrefs.includes('leastWalking'),
    accessible: selectedPrefs.includes('accessible'),
    strollerFriendly: selectedPrefs.includes('strollerFriendly'),
    avoidModes: [selectedPrefs.includes('avoidBoats') ? 'boat' : undefined, selectedPrefs.includes('avoidSkyliner') ? 'skyliner' : undefined].filter(Boolean) as TransportMode[]
  }), [selectedPrefs]);
  const routes = useMemo(() => calculateAlternativeRoutes(from, to, preferences), [from, to, preferences]);
  const best = chosen ?? routes[0] ?? null;
  const fromName = transportNodes.find((node) => node.id === from)?.name ?? 'Start';
  const toName = transportNodes.find((node) => node.id === to)?.name ?? 'Destination';

  return (
    <div className="space-y-6">
      <SectionTitle eyebrow="Routes" title="A resort route planner that actually thinks about transfers.">
        Times are estimates from editable seed data. Treat them as planning guidance unless connected to a verified live transportation source.
      </SectionTitle>
      <InlineNotice>Transportation estimates are not official live Disney bus, monorail, Skyliner, or boat arrivals. Verify service in the moment, especially during weather, late nights, and post-fireworks exits.</InlineNotice>
      <div className="grid gap-6 lg:grid-cols-[24rem_1fr]">
        <Card className="lg:sticky lg:top-28 lg:self-start">
          <div className="grid gap-4">
            <SelectNode label="Starting point" value={from} onChange={setFrom} />
            <SelectNode label="Destination" value={to} onChange={setTo} />
            <label className="grid gap-2 text-sm font-bold text-cream/70">Time<select className="input" value={timeMode} onChange={(e) => setTimeMode(e.target.value)}><option>Leave now</option><option>Arrive by</option><option>Leave at</option></select></label>
            <div>
              <p className="mb-3 text-sm font-bold text-cream/70">Preferences</p>
              <div className="flex flex-wrap gap-2">
                {preferenceOptions.map((pref) => {
                  const active = selectedPrefs.includes(pref.id);
                  return <button key={pref.id} onClick={() => setSelectedPrefs((current) => active ? current.filter((item) => item !== pref.id) : [...current, pref.id])} className={`rounded-full border px-4 py-2 text-sm font-bold ${active ? 'border-gold bg-gold text-midnight' : 'border-white/10 bg-white/[0.06] text-cream/70 hover:bg-white/10'}`}>{pref.label}</button>;
                })}
              </div>
            </div>
          </div>
        </Card>
        <div className="grid gap-6">
          {best ? <BestRouteCard route={best} fromName={fromName} toName={toName} onSave={() => saveRoute(fromName, toName, best)} onReverse={() => { setFrom(to); setTo(from); setChosen(null); }} onSend={() => addItineraryItem({ type: 'transportation', title: `${fromName} → ${toName}`, startTime: '18:00', endTime: '18:45', notes: `${best.label}. ${best.caveats[0] ?? 'Estimated route.'}` })} /> : <EmptyState title="No route found" body="Try allowing more transportation modes or choose a different start and destination. The seed graph is intentionally editable." />}
          <Card>
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Alternative routes</h2>
            <div className="grid gap-3">
              {routes.map((route, index) => <button key={route.id} onClick={() => setChosen(route)} className="rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4 text-left transition hover:bg-white/10"><div className="flex items-center justify-between"><span className="font-black text-cream light:text-slate-950">{index === 0 ? 'Best route' : `Alternative ${index}`}</span><Badge>{formatMinutes(route.totalDurationMin)}</Badge></div><p className="mt-2 text-sm text-cream/58 light:text-slate-600">{route.steps.map((step) => modeLabel(step.mode)).join(' → ')} · {route.transferCount} transfer{route.transferCount === 1 ? '' : 's'}</p></button>)}
            </div>
          </Card>
          <Card className="hidden min-h-[28rem] lg:block">
            <h2 className="mb-4 text-xl font-black text-cream light:text-slate-950">Map split view</h2>
            <div className="relative h-[24rem] overflow-hidden rounded-[2rem] border border-white/10 bg-[radial-gradient(circle_at_25%_25%,rgba(112,200,255,0.18),transparent_18rem),radial-gradient(circle_at_75%_60%,rgba(246,217,138,0.18),transparent_16rem),rgba(255,255,255,0.05)]">
              {best?.steps.map((step, index) => <motion.div key={step.id} initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: index * 0.15 }} className="absolute left-[15%] right-[15%] h-1 origin-left rounded-full bg-gold/70" style={{ top: `${22 + index * 18}%` }} />)}
              <div className="absolute left-[12%] top-[16%] rounded-2xl bg-sky px-3 py-2 text-sm font-black text-midnight">{fromName}</div>
              <div className="absolute bottom-[16%] right-[12%] rounded-2xl bg-gold px-3 py-2 text-sm font-black text-midnight">{toName}</div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SelectNode({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  const groups = transportNodes.reduce<Record<string, typeof transportNodes>>((acc, node) => {
    acc[node.type] = [...(acc[node.type] ?? []), node];
    return acc;
  }, {});
  return (
    <label className="grid gap-2 text-sm font-bold text-cream/70">{label}<select className="input" value={value} onChange={(event) => onChange(event.target.value)}>{Object.entries(groups).map(([group, nodes]) => <optgroup key={group} label={group}>{nodes.map((node) => <option key={node.id} value={node.id}>{node.name}</option>)}</optgroup>)}</select></label>
  );
}

function BestRouteCard({ route, fromName, toName, onSave, onReverse, onSend }: { route: CalculatedRoute; fromName: string; toName: string; onSave: () => void; onReverse: () => void; onSend: () => void }) {
  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <Badge>Best route</Badge>
          <h2 className="mt-3 text-3xl font-black text-cream light:text-slate-950">{fromName} → {toName}</h2>
          <p className="mt-2 text-cream/62 light:text-slate-600">{formatMinutes(route.totalDurationMin)} total · {Math.round(route.totalWalkingDistance)} ft walking · {route.transferCount} transfer{route.transferCount === 1 ? '' : 's'}</p>
        </div>
        <div className="flex flex-wrap gap-2"><Button variant="gold" onClick={onSave}>Save route</Button><Button onClick={onReverse}>Reverse</Button><Button onClick={onSend}>Send to Today</Button></div>
      </div>
      <div className="mt-6 space-y-4">
        {route.steps.map((step, index) => <motion.div key={step.id} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.08 }} className="grid gap-3 rounded-[1.5rem] border border-white/10 bg-white/[0.06] p-4 md:grid-cols-[3rem_1fr_auto]"><div className="grid size-12 place-items-center rounded-2xl bg-sky/14 text-xl">{modeIcon(step.mode)}</div><div><p className="font-black text-cream light:text-slate-950">{index + 1}. {instruction(step)}</p><p className="mt-1 text-sm text-cream/58 light:text-slate-600">{step.notes[0] ?? 'Estimated timing. Add a buffer during peak exits.'}</p></div><Badge>{formatMinutes(step.durationMin)}</Badge></motion.div>)}
      </div>
      {route.caveats.length ? <div className="mt-5 rounded-[1.5rem] border border-gold/20 bg-gold/10 p-4"><p className="font-black text-gold">Transfer warnings and accessibility notes</p><ul className="mt-2 space-y-1 text-sm leading-6 text-gold/84">{route.caveats.map((note) => <li key={note}>• {note}</li>)}</ul></div> : null}
      <div className="sticky bottom-20 mt-5 rounded-[1.5rem] border border-white/10 bg-midnight/85 p-3 backdrop-blur md:hidden"><Button className="w-full" variant="gold">Start route</Button></div>
    </Card>
  );
}

function instruction(step: CalculatedRoute['steps'][number]) {
  if (step.mode === 'walk') return `Walk from ${step.from.name} to ${step.to.name}`;
  return `Take ${modeLabel(step.mode)} from ${step.from.name} to ${step.to.name}`;
}
function modeLabel(mode: string) { return mode.charAt(0).toUpperCase() + mode.slice(1); }
function modeIcon(mode: string) { return ({ walk: '↟', bus: '▰', monorail: '━', skyliner: '◌', boat: '≈', rideshare: '◆', car: '◆' } as Record<string, string>)[mode] ?? '↬'; }
