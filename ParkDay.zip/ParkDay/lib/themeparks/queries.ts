export const themeparksKeys = {
  all: ['themeparks'] as const,
  destinations: () => [...themeparksKeys.all, 'destinations'] as const,
  wdwDestination: () => [...themeparksKeys.all, 'destination', 'walt-disney-world'] as const,
  parks: (destinationId?: string) => [...themeparksKeys.all, 'parks', destinationId] as const,
  children: (parkId?: string) => [...themeparksKeys.all, 'children', parkId] as const,
  live: (parkId?: string) => [...themeparksKeys.all, 'live', parkId] as const,
  schedule: (parkId?: string) => [...themeparksKeys.all, 'schedule', parkId] as const
};
