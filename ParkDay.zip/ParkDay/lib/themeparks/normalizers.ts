import type { Attraction, Destination, Entity, EntityStatus, LiveData, Park, ParkSchedule, Restaurant, Show } from '@/lib/types';
import type { ThemeParksDestinationRaw, ThemeParksEntityRaw, ThemeParksLiveRaw, ThemeParksScheduleRaw } from '@/lib/types/themeparks';

function entityId(raw: ThemeParksEntityRaw | ThemeParksDestinationRaw | ThemeParksLiveRaw) {
  return String(raw.id ?? raw.entityId ?? '');
}

export function asArray<T>(raw: unknown, keys: string[] = []) {
  if (Array.isArray(raw)) return raw as T[];
  if (raw && typeof raw === 'object') {
    const source = raw as Record<string, unknown>;
    for (const key of keys) {
      if (Array.isArray(source[key])) return source[key] as T[];
    }
  }
  return [];
}

export function normalizeDestination(raw: ThemeParksDestinationRaw): Destination | null {
  const id = entityId(raw);
  const name = raw.name;
  if (!id || !name) return null;
  return {
    id,
    name,
    slug: raw.slug,
    timezone: raw.timezone,
    location: raw.location
  };
}

export function normalizeEntityType(type?: string) {
  const normalized = (type ?? 'UNKNOWN').toUpperCase();
  if (['DESTINATION', 'PARK', 'ATTRACTION', 'RESTAURANT', 'SHOW', 'HOTEL', 'LAND'].includes(normalized)) return normalized as Entity['entityType'];
  return 'UNKNOWN';
}

export function normalizePark(raw: ThemeParksEntityRaw): Park | null {
  const id = entityId(raw);
  const name = raw.name;
  if (!id || !name) return null;
  return {
    id,
    name,
    destinationId: raw.destinationId,
    entityType: normalizeEntityType(raw.entityType ?? raw.type),
    timezone: raw.timezone,
    location: raw.location
  };
}

export function normalizeEntity(raw: ThemeParksEntityRaw): Entity | null {
  const id = entityId(raw);
  const name = raw.name;
  if (!id || !name) return null;
  const type = normalizeEntityType(raw.entityType ?? raw.type);
  return {
    id,
    name,
    entityType: type,
    parentId: raw.parentId,
    parkId: raw.destinationId,
    location: raw.location,
    tags: []
  };
}

export function normalizeStatus(status?: string): EntityStatus {
  const normalized = (status ?? 'UNKNOWN').toUpperCase();
  if (normalized.includes('OPERATING')) return 'OPERATING';
  if (normalized.includes('REFURB')) return 'REFURBISHMENT';
  if (normalized.includes('DOWN')) return 'DOWN';
  if (normalized.includes('CLOSED')) return 'CLOSED';
  return 'UNKNOWN';
}

export function normalizeLiveData(raw: ThemeParksLiveRaw): LiveData | null {
  const id = entityId(raw);
  if (!id) return null;
  const standby = raw.queue?.STANDBY?.waitTime ?? raw.queue?.standby?.waitTime ?? null;
  const singleRider = raw.queue?.SINGLE_RIDER?.waitTime ?? null;
  const returnTime = raw.queue?.BOARDING_GROUP?.returnStart ?? raw.queue?.LIGHTNING_LANE?.returnStart ?? null;
  return {
    entityId: id,
    name: raw.name,
    status: normalizeStatus(raw.status),
    waitTime: { standby, singleRider, returnTime, lastChanged: raw.lastUpdated },
    showtimes: Array.isArray(raw.showtimes)
      ? raw.showtimes
          .filter((showtime) => showtime.startTime)
          .map((showtime) => ({ startTime: String(showtime.startTime), endTime: showtime.endTime, type: showtime.type }))
      : [],
    lastUpdated: raw.lastUpdated
  };
}

export function mergeChildrenWithLiveData(children: Entity[], liveData: LiveData[], favorites: string[] = []): Attraction[] {
  const liveById = new Map(liveData.map((item) => [item.entityId, item]));
  return children
    .filter((child) => ['ATTRACTION', 'UNKNOWN'].includes(child.entityType))
    .map((child) => {
      const live = liveById.get(child.id);
      return {
        ...child,
        entityType: 'ATTRACTION' as const,
        status: live?.status ?? 'UNKNOWN',
        waitTime: live?.waitTime,
        operatingNow: live?.status === 'OPERATING',
        isFavorite: favorites.includes(child.id),
        lastUpdated: live?.lastUpdated,
        thrillLevel: inferThrill(child.name),
        indoor: inferIndoor(child.name),
        familyFriendly: !/(tower|mountain|coaster|mission|guardian|tron|flight of passage)/i.test(child.name)
      } satisfies Attraction;
    });
}

export function normalizeAttractions(children: Entity[], liveData: LiveData[], favorites: string[] = []) {
  return mergeChildrenWithLiveData(children, liveData, favorites);
}

export function normalizeRestaurants(children: Entity[]): Restaurant[] {
  return children
    .filter((child) => child.entityType === 'RESTAURANT')
    .map((child) => ({ ...child, entityType: 'RESTAURANT' as const, priceLevel: '$$', tags: [], type: 'Dining' }));
}

export function normalizeShows(children: Entity[], liveData: LiveData[]): Show[] {
  const liveById = new Map(liveData.map((item) => [item.entityId, item]));
  return children
    .filter((child) => child.entityType === 'SHOW')
    .map((child) => ({ ...child, entityType: 'SHOW' as const, showtimes: liveById.get(child.id)?.showtimes ?? [] }));
}

export function normalizeSchedule(raw: ThemeParksScheduleRaw, parkId: string): ParkSchedule | null {
  if (!raw.date) return null;
  return {
    parkId,
    date: raw.date,
    openingTime: raw.openingTime,
    closingTime: raw.closingTime,
    type: raw.type,
    raw
  };
}

function inferThrill(name: string): Attraction['thrillLevel'] {
  if (/(tron|tower|rock|everest|cosmic rewind|flight of passage|space mountain|slinky|test track)/i.test(name)) return 'high';
  if (/(pirates|safari|runaway railway|soarin|big thunder|remy|ratatouille)/i.test(name)) return 'moderate';
  return 'gentle';
}

function inferIndoor(name: string) {
  return /(mansion|pirates|space|small world|buzz|soarin|remy|ratatouille|journey|muppet|tower|runaway|frozen)/i.test(name);
}
