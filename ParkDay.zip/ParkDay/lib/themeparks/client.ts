import type { Destination, Entity, LiveData, Park, ParkSchedule } from '@/lib/types';
import type { ThemeParksDestinationRaw, ThemeParksEntityRaw, ThemeParksLiveRaw, ThemeParksScheduleRaw } from '@/lib/types/themeparks';
import { asArray, normalizeDestination, normalizeEntity, normalizeLiveData, normalizePark, normalizeSchedule } from './normalizers';

export const THEMEPARKS_API_BASE = process.env.NEXT_PUBLIC_THEMEPARKS_API_BASE ?? 'https://api.themeparks.wiki/v1';

export class ThemeParksApiError extends Error {
  constructor(message: string, public status?: number, public url?: string) {
    super(message);
    this.name = 'ThemeParksApiError';
  }
}

async function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function themeParksFetch<T>(path: string, init?: RequestInit, retries = 2): Promise<T> {
  const url = `${THEMEPARKS_API_BASE}${path.startsWith('/') ? path : `/${path}`}`;
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const response = await fetch(url, {
        ...init,
        headers: {
          Accept: 'application/json',
          ...(init?.headers ?? {})
        },
        cache: init?.cache ?? 'default'
      });
      if (!response.ok) {
        if (response.status >= 500 && attempt < retries) {
          await delay(400 * (attempt + 1));
          continue;
        }
        throw new ThemeParksApiError(`ThemeParks.wiki returned ${response.status}`, response.status, url);
      }
      return (await response.json()) as T;
    } catch (error) {
      lastError = error;
      if (attempt < retries) await delay(400 * (attempt + 1));
    }
  }
  if (lastError instanceof Error) throw lastError;
  throw new ThemeParksApiError('Unable to reach ThemeParks.wiki', undefined, url);
}

export async function fetchDestinations(): Promise<Destination[]> {
  const raw = await themeParksFetch<unknown>('/destinations');
  return asArray<ThemeParksDestinationRaw>(raw, ['destinations'])
    .map(normalizeDestination)
    .filter(Boolean) as Destination[];
}

export async function findDestinationByName(name: string): Promise<Destination | null> {
  const destinations = await fetchDestinations();
  const clean = name.toLowerCase();
  return destinations.find((destination) => destination.name.toLowerCase().includes(clean)) ?? null;
}

export async function getDestinationByName(name: string) {
  return findDestinationByName(name);
}

export async function getParksForDestination(destinationId: string): Promise<Park[]> {
  const children = await getEntityChildren(destinationId);
  return children
    .filter((entity) => entity.entityType === 'PARK' || /park|epcot|kingdom|studios|springs|beach|lagoon/i.test(entity.name))
    .map((entity) => ({ ...entity, entityType: 'PARK' as const, destinationId }));
}

export async function getParkChildren(parkEntityId: string): Promise<Entity[]> {
  return getEntityChildren(parkEntityId);
}

export async function getEntity(entityId: string): Promise<Entity | Park | null> {
  const raw = await themeParksFetch<ThemeParksEntityRaw>(`/entity/${entityId}`);
  return normalizePark(raw) ?? normalizeEntity(raw);
}

export async function getEntityChildren(entityId: string): Promise<Entity[]> {
  const raw = await themeParksFetch<unknown>(`/entity/${entityId}/children`);
  return asArray<ThemeParksEntityRaw>(raw, ['children', 'entities'])
    .map(normalizeEntity)
    .filter(Boolean) as Entity[];
}

export async function getParkLiveData(parkEntityId: string): Promise<LiveData[]> {
  const raw = await themeParksFetch<unknown>(`/entity/${parkEntityId}/live`, { cache: 'no-store' });
  return asArray<ThemeParksLiveRaw>(raw, ['liveData'])
    .map(normalizeLiveData)
    .filter(Boolean) as LiveData[];
}

export async function getEntityLiveData(parkEntityId: string) {
  return getParkLiveData(parkEntityId);
}

export async function getParkSchedule(parkEntityId: string): Promise<ParkSchedule[]> {
  const raw = await themeParksFetch<unknown>(`/entity/${parkEntityId}/schedule`);
  return asArray<ThemeParksScheduleRaw>(raw, ['schedule'])
    .map((item) => normalizeSchedule(item, parkEntityId))
    .filter(Boolean) as ParkSchedule[];
}

export async function getParkScheduleMonth(parkEntityId: string, year: number, month: number): Promise<ParkSchedule[]> {
  const raw = await themeParksFetch<unknown>(`/entity/${parkEntityId}/schedule/${year}/${month}`);
  return asArray<ThemeParksScheduleRaw>(raw, ['schedule'])
    .map((item) => normalizeSchedule(item, parkEntityId))
    .filter(Boolean) as ParkSchedule[];
}

export async function getParkScheduleByDate(parkEntityId: string, date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  return getParkScheduleMonth(parkEntityId, year, month);
}

export { normalizeAttractions, normalizeRestaurants, normalizeShows, mergeChildrenWithLiveData } from './normalizers';
