'use client';

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { CalculatedRoute, ItineraryItem, SavedRoute, TripPlan, UserPreferences } from '@/lib/types';
import { todayISO, uid } from '@/lib/utils';

interface ParkDayState {
  preferences: UserPreferences;
  favorites: string[];
  favoriteNames: Record<string, string>;
  tripPlan?: TripPlan;
  itinerary: ItineraryItem[];
  savedRoutes: SavedRoute[];
  notes: string[];
  packingChecklist: Record<string, boolean>;
  setPreference: <K extends keyof UserPreferences>(key: K, value: UserPreferences[K]) => void;
  setSelectedPark: (parkId: string, parkName: string) => void;
  toggleFavorite: (id: string, name?: string) => void;
  saveTripPlan: (plan: TripPlan) => void;
  addItineraryItem: (item: Omit<ItineraryItem, 'id'>) => void;
  updateItineraryItem: (id: string, item: Partial<ItineraryItem>) => void;
  removeItineraryItem: (id: string) => void;
  reorderItinerary: (fromIndex: number, toIndex: number) => void;
  saveRoute: (from: string, to: string, route: CalculatedRoute) => void;
  removeSavedRoute: (id: string) => void;
  togglePackingItem: (id: string) => void;
  addNote: (note: string) => void;
  removeNote: (index: number) => void;
}

const defaultPreferences: UserPreferences = {
  selectedDate: todayISO(),
  lowWalkingMode: false,
  toddlerMode: false,
  rainyDayMode: false,
  batterySaver: false,
  avoidClosed: true,
  hideIneligibleRides: false,
  bufferMinutes: 10,
  theme: 'dark'
};

export const useParkDayStore = create<ParkDayState>()(
  persist(
    (set) => ({
      preferences: defaultPreferences,
      favorites: [],
      favoriteNames: {},
      itinerary: [],
      savedRoutes: [],
      notes: [],
      packingChecklist: {},
      setPreference: (key, value) => set((state) => ({ preferences: { ...state.preferences, [key]: value } })),
      setSelectedPark: (parkId, parkName) =>
        set((state) => ({ preferences: { ...state.preferences, selectedParkId: parkId, selectedParkName: parkName } })),
      toggleFavorite: (id, name) =>
        set((state) => {
          const exists = state.favorites.includes(id);
          const favoriteNames = { ...state.favoriteNames };
          if (name) favoriteNames[id] = name;
          if (exists) delete favoriteNames[id];
          return { favorites: exists ? state.favorites.filter((item) => item !== id) : [...state.favorites, id], favoriteNames };
        }),
      saveTripPlan: (plan) => set({ tripPlan: plan }),
      addItineraryItem: (item) => set((state) => ({ itinerary: [...state.itinerary, { ...item, id: uid('itin') }] })),
      updateItineraryItem: (id, item) =>
        set((state) => ({ itinerary: state.itinerary.map((entry) => (entry.id === id ? { ...entry, ...item } : entry)) })),
      removeItineraryItem: (id) => set((state) => ({ itinerary: state.itinerary.filter((entry) => entry.id !== id) })),
      reorderItinerary: (fromIndex, toIndex) =>
        set((state) => {
          const next = [...state.itinerary];
          const [moved] = next.splice(fromIndex, 1);
          next.splice(toIndex, 0, moved);
          return { itinerary: next };
        }),
      saveRoute: (from, to, route) =>
        set((state) => ({
          savedRoutes: [{ id: uid('route'), from, to, route, savedAt: new Date().toISOString() }, ...state.savedRoutes].slice(0, 30)
        })),
      removeSavedRoute: (id) => set((state) => ({ savedRoutes: state.savedRoutes.filter((route) => route.id !== id) })),
      togglePackingItem: (id) =>
        set((state) => ({ packingChecklist: { ...state.packingChecklist, [id]: !state.packingChecklist[id] } })),
      addNote: (note) => set((state) => ({ notes: [note, ...state.notes].slice(0, 50) })),
      removeNote: (index) => set((state) => ({ notes: state.notes.filter((_, noteIndex) => noteIndex !== index) }))
    }),
    {
      name: 'parkday-v1',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        preferences: state.preferences,
        favorites: state.favorites,
        favoriteNames: state.favoriteNames,
        tripPlan: state.tripPlan,
        itinerary: state.itinerary,
        savedRoutes: state.savedRoutes,
        notes: state.notes,
        packingChecklist: state.packingChecklist
      })
    }
  )
);
