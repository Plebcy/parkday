import type { EntityType } from './index';

export interface ThemeParksDestinationRaw {
  id?: string;
  entityId?: string;
  name?: string;
  slug?: string;
  timezone?: string;
  location?: { latitude?: number; longitude?: number };
  parks?: ThemeParksEntityRaw[];
  children?: ThemeParksEntityRaw[];
  [key: string]: unknown;
}

export interface ThemeParksEntityRaw {
  id?: string;
  entityId?: string;
  name?: string;
  entityType?: EntityType | string;
  type?: string;
  parentId?: string;
  destinationId?: string;
  timezone?: string;
  location?: { latitude?: number; longitude?: number };
  children?: ThemeParksEntityRaw[];
  [key: string]: unknown;
}

export interface ThemeParksLiveRaw {
  id?: string;
  entityId?: string;
  name?: string;
  status?: string;
  queue?: Record<string, { waitTime?: number | null; returnStart?: string; returnEnd?: string; state?: string }>;
  showtimes?: Array<{ startTime?: string; endTime?: string; type?: string }>;
  diningAvailability?: unknown;
  lastUpdated?: string;
  [key: string]: unknown;
}

export interface ThemeParksScheduleRaw {
  date?: string;
  type?: string;
  openingTime?: string;
  closingTime?: string;
  [key: string]: unknown;
}
