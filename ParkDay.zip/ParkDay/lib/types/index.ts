export type EntityType = 'DESTINATION' | 'PARK' | 'ATTRACTION' | 'RESTAURANT' | 'SHOW' | 'HOTEL' | 'LAND' | 'UNKNOWN';
export type EntityStatus = 'OPERATING' | 'CLOSED' | 'DOWN' | 'REFURBISHMENT' | 'UNKNOWN';
export type WaitSort = 'lowest' | 'highest' | 'alpha' | 'nearby' | 'changed';
export type TransportMode = 'walk' | 'bus' | 'monorail' | 'skyliner' | 'boat' | 'rideshare' | 'car';
export type Pace = 'relaxed' | 'balanced' | 'maximize';

export interface Destination {
  id: string;
  name: string;
  slug?: string;
  timezone?: string;
  location?: GeoLocation;
}

export interface GeoLocation {
  latitude?: number;
  longitude?: number;
}

export interface Park {
  id: string;
  name: string;
  destinationId?: string;
  entityType: EntityType;
  timezone?: string;
  location?: GeoLocation;
}

export interface Entity {
  id: string;
  name: string;
  entityType: EntityType;
  parkId?: string;
  parentId?: string;
  land?: string;
  location?: GeoLocation;
  tags?: string[];
}

export interface WaitTime {
  standby?: number | null;
  singleRider?: number | null;
  returnTime?: string | null;
  lastChanged?: string | null;
}

export interface LiveData {
  entityId: string;
  name?: string;
  status: EntityStatus;
  waitTime?: WaitTime;
  showtimes?: ShowTime[];
  dining?: DiningLiveInfo;
  lastUpdated?: string;
}

export interface ShowTime {
  startTime: string;
  endTime?: string;
  type?: string;
}

export interface DiningLiveInfo {
  acceptingMobileOrder?: boolean;
  availableTimes?: string[];
  statusText?: string;
}

export interface Attraction extends Entity {
  entityType: 'ATTRACTION';
  status?: EntityStatus;
  waitTime?: WaitTime;
  isFavorite?: boolean;
  operatingNow?: boolean;
  lastUpdated?: string;
  thrillLevel?: 'gentle' | 'moderate' | 'high';
  indoor?: boolean;
  familyFriendly?: boolean;
  heightRequirement?: string;
}

export interface Restaurant extends Entity {
  entityType: 'RESTAURANT';
  locationLabel?: string;
  type?: string;
  cuisine?: string[];
  priceLevel?: '$' | '$$' | '$$$' | '$$$$';
  tags?: string[];
  reservationRecommended?: boolean;
  mobileOrder?: boolean;
  bestFor?: string[];
}

export interface Show extends Entity {
  entityType: 'SHOW';
  showtimes?: ShowTime[];
}

export interface ParkSchedule {
  parkId: string;
  date: string;
  openingTime?: string;
  closingTime?: string;
  type?: string;
  raw?: unknown;
}

export interface TripPlan {
  id: string;
  name: string;
  arrivalDate: string;
  departureDate: string;
  resort: string;
  partySize: number;
  ages: string;
  mobilityNeeds: string;
  parksPlanned: string[];
  priorities: string[];
  pace: Pace;
  budgetPreferences: string[];
  transportationPreferences: TransportMode[];
  generatedDays: PlannedDay[];
  updatedAt: string;
}

export interface PlannedDay {
  id: string;
  date: string;
  park: string;
  arrivalTime: string;
  blocks: PlannedBlock[];
  notes: string[];
}

export interface PlannedBlock {
  id: string;
  label: 'Morning' | 'Afternoon' | 'Evening';
  title: string;
  items: string[];
  travelNote?: string;
}

export interface ItineraryItem {
  id: string;
  type: 'attraction' | 'dining' | 'show' | 'break' | 'transportation' | 'note';
  title: string;
  park?: string;
  startTime: string;
  endTime: string;
  notes?: string;
  sourceId?: string;
  completed?: boolean;
}

export interface SavedRoute {
  id: string;
  from: string;
  to: string;
  route: CalculatedRoute;
  savedAt: string;
}

export interface TransportNode {
  id: string;
  name: string;
  type: 'resort' | 'park' | 'hub' | 'station' | 'dock' | 'stop' | 'custom' | 'dining' | 'land';
  area?: string;
  coordinates?: GeoLocation;
  tags?: string[];
}

export interface TransportEdge {
  id: string;
  from: string;
  to: string;
  estimatedDurationMin: number;
  transferPenaltyMin: number;
  walkingDistance: number;
  mode: TransportMode;
  accessibilityNotes?: string;
  operatingCaveats?: string;
  strollerFriendly?: boolean;
  bidirectional?: boolean;
}

export interface RouteStep {
  id: string;
  from: TransportNode;
  to: TransportNode;
  mode: TransportMode;
  durationMin: number;
  walkingDistance: number;
  notes: string[];
}

export interface CalculatedRoute {
  id: string;
  totalDurationMin: number;
  totalWalkingDistance: number;
  transferCount: number;
  steps: RouteStep[];
  score: number;
  label: string;
  caveats: string[];
}

export interface DiningLocation {
  id: string;
  name: string;
  location: string;
  parkOrResort: string;
  type: 'Quick service' | 'Table service' | 'Character dining' | 'Lounge' | 'Snack';
  cuisine: string[];
  priceLevel: '$' | '$$' | '$$$' | '$$$$';
  dietaryTags: string[];
  tags: string[];
  bestFor: string[];
  suggestedTimes: string[];
  nearbyAttractions: string[];
  overview: string;
  mobileOrder: boolean;
  reservationRecommended: boolean;
  coordinates?: { x: number; y: number };
}

export interface UserPreferences {
  selectedParkId?: string;
  selectedParkName?: string;
  selectedDate?: string;
  lowWalkingMode: boolean;
  toddlerMode: boolean;
  rainyDayMode: boolean;
  batterySaver: boolean;
  avoidClosed: boolean;
  hideIneligibleRides: boolean;
  bufferMinutes: number;
  theme: 'dark' | 'light';
}

export interface MapPin {
  id: string;
  name: string;
  park: string;
  type: 'attraction' | 'dining' | 'restroom' | 'transportation' | 'guest-services' | 'first-aid' | 'water';
  x: number;
  y: number;
  entityId?: string;
  notes?: string;
}
