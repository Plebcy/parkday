import type { CalculatedRoute, RouteStep, TransportEdge } from '@/lib/types';
import { edgeCost, expandedEdges, getNode, transportEdges, type RoutePreferences } from './graph';
import { formatMinutes, uid } from '@/lib/utils';

export function calculateRoute(startId: string, endId: string, preferences: RoutePreferences = {}, excludedEdgeIds: string[] = []): CalculatedRoute | null {
  if (!startId || !endId || startId === endId) return null;
  const edges = expandedEdges(transportEdges).filter((edge) => !excludedEdgeIds.includes(edge.id.replace('-reverse', '')));
  const distances = new Map<string, number>([[startId, 0]]);
  const previous = new Map<string, { nodeId: string; edge: TransportEdge }>();
  const queue = new Set<string>([startId, endId, ...edges.flatMap((edge) => [edge.from, edge.to])]);

  while (queue.size) {
    let current: string | undefined;
    let best = Infinity;
    queue.forEach((nodeId) => {
      const distance = distances.get(nodeId) ?? Infinity;
      if (distance < best) {
        best = distance;
        current = nodeId;
      }
    });
    if (!current || best === Infinity) break;
    queue.delete(current);
    if (current === endId) break;

    for (const edge of edges.filter((candidate) => candidate.from === current)) {
      const candidate = best + edgeCost(edge, preferences);
      if (candidate < (distances.get(edge.to) ?? Infinity)) {
        distances.set(edge.to, candidate);
        previous.set(edge.to, { nodeId: current, edge });
      }
    }
  }

  if (!previous.has(endId)) return null;
  const steps: RouteStep[] = [];
  let cursor = endId;
  while (cursor !== startId) {
    const entry = previous.get(cursor);
    if (!entry) return null;
    const from = getNode(entry.edge.from);
    const to = getNode(entry.edge.to);
    if (!from || !to) return null;
    steps.unshift({
      id: uid('step'),
      from,
      to,
      mode: entry.edge.mode,
      durationMin: entry.edge.estimatedDurationMin + entry.edge.transferPenaltyMin,
      walkingDistance: entry.edge.walkingDistance,
      notes: [
        entry.edge.accessibilityNotes,
        entry.edge.operatingCaveats,
        entry.edge.transferPenaltyMin > 0 ? `Includes about ${entry.edge.transferPenaltyMin} minutes of transfer/wait buffer.` : undefined
      ].filter(Boolean) as string[]
    });
    cursor = entry.nodeId;
  }
  const totalDurationMin = steps.reduce((sum, step) => sum + step.durationMin, 0);
  const totalWalkingDistance = steps.reduce((sum, step) => sum + step.walkingDistance, 0);
  const transferCount = Math.max(0, steps.filter((step) => step.mode !== 'walk').length - 1);
  const caveats = Array.from(new Set(steps.flatMap((step) => step.notes))).slice(0, 4);
  return {
    id: uid('calc-route'),
    totalDurationMin,
    totalWalkingDistance,
    transferCount,
    steps,
    score: distances.get(endId) ?? totalDurationMin,
    label: `Best route · ${formatMinutes(totalDurationMin)}`,
    caveats
  };
}

export function calculateAlternativeRoutes(startId: string, endId: string, preferences: RoutePreferences = {}) {
  const best = calculateRoute(startId, endId, preferences);
  if (!best) return [];
  const alternatives = best.steps
    .slice(0, 2)
    .map((step) => calculateRoute(startId, endId, preferences, [edgeIdFromStep(step.from.id, step.to.id)]))
    .filter(Boolean) as CalculatedRoute[];
  return [best, ...alternatives]
    .filter((route, index, routes) => routes.findIndex((candidate) => candidate.steps.map((step) => `${step.from.id}-${step.to.id}`).join('|') === route.steps.map((step) => `${step.from.id}-${step.to.id}`).join('|')) === index)
    .sort((a, b) => a.score - b.score)
    .slice(0, 3);
}

function edgeIdFromStep(from: string, to: string) {
  const edge = transportEdges.find((item) => (item.from === from && item.to === to) || (item.bidirectional && item.from === to && item.to === from));
  return edge?.id ?? `${from}-${to}`;
}
