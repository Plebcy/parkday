import nodesJson from '@/data/seed/transportNodes.json';
import edgesJson from '@/data/seed/transportEdges.json';
import type { TransportEdge, TransportMode, TransportNode } from '@/lib/types';

export const transportNodes = nodesJson as TransportNode[];
export const transportEdges = edgesJson as TransportEdge[];

export interface RoutePreferences {
  fastest?: boolean;
  fewestTransfers?: boolean;
  leastWalking?: boolean;
  avoidModes?: TransportMode[];
  accessible?: boolean;
  strollerFriendly?: boolean;
}

export function getNode(id: string) {
  return transportNodes.find((node) => node.id === id);
}

export function expandedEdges(edges = transportEdges) {
  return edges.flatMap((edge) => (edge.bidirectional ? [edge, { ...edge, id: `${edge.id}-reverse`, from: edge.to, to: edge.from }] : [edge]));
}

export function edgeCost(edge: TransportEdge, preferences: RoutePreferences) {
  let cost = edge.estimatedDurationMin + edge.transferPenaltyMin;
  if (preferences.fewestTransfers) cost += edge.transferPenaltyMin * 1.7;
  if (preferences.leastWalking) cost += edge.walkingDistance / 80;
  if (preferences.avoidModes?.includes(edge.mode)) cost += 10_000;
  if (preferences.accessible && edge.accessibilityNotes?.toLowerCase().includes('depends')) cost += 12;
  if (preferences.strollerFriendly && edge.strollerFriendly === false) cost += 18;
  if (preferences.fastest) cost -= Math.min(3, edge.estimatedDurationMin * 0.05);
  return cost;
}
