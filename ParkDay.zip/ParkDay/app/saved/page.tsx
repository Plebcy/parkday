import { SavedHub } from '@/components/saved/SavedHub';
import { MotionPage } from '@/components/ui/Motion';

export default function SavedPage() {
  return (
    <MotionPage>
      <SavedHub />
    </MotionPage>
  );
}
