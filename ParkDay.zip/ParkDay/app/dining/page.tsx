import { DiningExplorer } from '@/components/dining/DiningExplorer';
import { MotionPage } from '@/components/ui/Motion';

export default function DiningPage() {
  return (
    <MotionPage>
      <DiningExplorer />
    </MotionPage>
  );
}
