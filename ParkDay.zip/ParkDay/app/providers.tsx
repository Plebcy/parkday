'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AnimatePresence } from 'framer-motion';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { usePathname } from 'next/navigation';
import { useParkDayStore } from '@/lib/storage/useParkDayStore';

export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 1000 * 30,
            retry: 1,
            refetchOnReconnect: true
          }
        }
      })
  );
  const pathname = usePathname();
  const theme = useParkDayStore((state) => state.preferences.theme);

  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light');
  }, [theme]);

  useEffect(() => {
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      navigator.serviceWorker.register('/sw.js').catch(() => undefined);
    }
  }, []);

  const key = useMemo(() => pathname, [pathname]);

  return (
    <QueryClientProvider client={client}>
      <AnimatePresence mode="wait" initial={false} key={key}>
        {children}
      </AnimatePresence>
    </QueryClientProvider>
  );
}
