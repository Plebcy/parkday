import { Dashboard } from '@/components/cards/Dashboard';
import { MotionPage } from '@/components/ui/Motion';

export default function HomePage() {
  return (
    <MotionPage>
      <Dashboard />
      <footer className="mt-12 rounded-[2rem] border border-white/10 bg-white/[0.05] p-6 text-sm leading-6 text-cream/58 light:text-slate-600">
        <strong className="text-cream light:text-slate-950">Unofficial disclaimer:</strong> ParkDay is an independent planning companion. It is not affiliated with, endorsed by, or sponsored by The Walt Disney Company or its subsidiaries. Live wait and schedule data is provided through public third-party data sources when available, and transportation/dining seed data should be verified before travel.
      </footer>
    </MotionPage>
  );
}
