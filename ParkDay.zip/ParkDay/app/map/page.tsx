import { InteractiveMap } from '@/components/map/InteractiveMap';
import { MotionPage } from '@/components/ui/Motion';

export default function MapPage() {
  return (
    <MotionPage>
      <InteractiveMap />
    </MotionPage>
  );
}
