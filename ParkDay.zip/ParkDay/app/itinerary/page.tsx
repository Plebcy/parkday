import { ItineraryBuilder } from '@/components/itinerary/ItineraryBuilder';
import { MotionPage } from '@/components/ui/Motion';

export default function ItineraryPage() {
  return (
    <MotionPage>
      <ItineraryBuilder />
    </MotionPage>
  );
}
