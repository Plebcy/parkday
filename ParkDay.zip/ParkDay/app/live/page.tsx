import { LiveWaitsClient } from '@/components/live/LiveWaitsClient';
import { MotionPage } from '@/components/ui/Motion';

export default function LiveParksPage() {
  return (
    <MotionPage>
      <LiveWaitsClient />
    </MotionPage>
  );
}
