import { RoutePlanner } from '@/components/routes/RoutePlanner';
import { MotionPage } from '@/components/ui/Motion';

export default function RoutesPage() {
  return (
    <MotionPage>
      <RoutePlanner />
    </MotionPage>
  );
}
