import { TripPlanner } from '@/components/planner/TripPlanner';
import { MotionPage } from '@/components/ui/Motion';

export default function PlanPage() {
  return (
    <MotionPage>
      <TripPlanner />
    </MotionPage>
  );
}
