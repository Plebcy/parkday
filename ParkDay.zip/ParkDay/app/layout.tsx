import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Providers } from './providers';
import { AppShell } from '@/components/navigation/AppShell';


export const metadata: Metadata = {
  title: 'ParkDay — Unofficial WDW Trip Companion',
  description: 'A premium, unofficial Walt Disney World planning and in-park navigation companion.',
  applicationName: 'ParkDay',
  manifest: '/manifest.json',
  appleWebApp: { capable: true, title: 'ParkDay', statusBarStyle: 'black-translucent' },
  icons: [{ rel: 'icon', url: '/icon.svg' }]
};

export const viewport: Viewport = {
  themeColor: '#071426',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <Providers>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  );
}
