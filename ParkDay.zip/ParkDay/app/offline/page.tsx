import { MotionPage } from '@/components/ui/Motion';
import { Card, SectionTitle } from '@/components/ui/Card';
import { LinkButton } from '@/components/ui/Button';

export default function OfflinePage() {
  return (
    <MotionPage>
      <Card>
        <SectionTitle eyebrow="Offline" title="ParkDay is keeping the essentials close.">
          Live waits and schedules need a connection, but saved plans, favorites, packing notes, and routes are designed to stay useful when signal gets spotty.
        </SectionTitle>
        <LinkButton href="/saved" variant="gold">Open saved hub</LinkButton>
      </Card>
    </MotionPage>
  );
}
