'use client';

import { useQuery } from '@tanstack/react-query';
import { fetchDestinations, findDestinationByName, getParkChildren, getParkLiveData, getParksForDestination, getParkSchedule } from '@/lib/themeparks/client';
import { themeparksKeys } from '@/lib/themeparks/queries';

const metadataCache = 1000 * 60 * 60 * 8;

export function useDestinations() {
  return useQuery({
    queryKey: themeparksKeys.destinations(),
    queryFn: fetchDestinations,
    staleTime: metadataCache,
    gcTime: metadataCache * 2
  });
}

export function useWdwDestination() {
  return useQuery({
    queryKey: themeparksKeys.wdwDestination(),
    queryFn: () => findDestinationByName('Walt Disney World'),
    staleTime: metadataCache,
    gcTime: metadataCache * 2
  });
}

export function useWdwParks() {
  const destination = useWdwDestination();
  const destinationId = destination.data?.id;
  const parks = useQuery({
    queryKey: themeparksKeys.parks(destinationId),
    queryFn: () => getParksForDestination(destinationId as string),
    enabled: Boolean(destinationId),
    staleTime: metadataCache,
    gcTime: metadataCache * 2
  });
  return { ...parks, destination: destination.data, destinationError: destination.error };
}

export function useParkChildren(parkId?: string) {
  return useQuery({
    queryKey: themeparksKeys.children(parkId),
    queryFn: () => getParkChildren(parkId as string),
    enabled: Boolean(parkId),
    staleTime: metadataCache,
    gcTime: metadataCache * 2
  });
}

export function useParkLiveData(parkId?: string, active = true) {
  return useQuery({
    queryKey: themeparksKeys.live(parkId),
    queryFn: () => getParkLiveData(parkId as string),
    enabled: Boolean(parkId) && active,
    staleTime: 1000 * 30,
    refetchInterval: active ? 1000 * 60 * 2 : false,
    refetchOnWindowFocus: true,
    retry: 1
  });
}

export function useParkSchedule(parkId?: string) {
  return useQuery({
    queryKey: themeparksKeys.schedule(parkId),
    queryFn: () => getParkSchedule(parkId as string),
    enabled: Boolean(parkId),
    staleTime: 1000 * 60 * 30,
    retry: 1
  });
}
